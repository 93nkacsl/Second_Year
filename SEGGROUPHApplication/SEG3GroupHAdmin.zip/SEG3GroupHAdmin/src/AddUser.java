import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AddUser {
	private String login_Path;
	private JDialog dialog;
	private JButton b_AddUser;
	private JTextField tf_Username;
	private JPasswordField tf_Password;
	private JCheckBox cb_ShowPass;
	private boolean valueChecked = false;

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}

	public AddUser(String login_Path) {
		this.login_Path = login_Path;
		gui();
		actionListener();
		// END
		setPosition(1, dialog, null);
		dialog.show();
	}

	private void gui() {
		dialog = new JDialog();
		dialog.setModal(true);
		JPanel mainPanel = new JPanel(new BorderLayout());
		JPanel middlePanel = new JPanel(new GridLayout(3, 1));
		// Top Panel
		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		topPanel.add(new JLabel("Add a user"));

		// Top Panel of middle panel
		JPanel nPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		nPanel.add(new JLabel("Username:"));
		tf_Username = new JTextField();
		tf_Username.setPreferredSize(new Dimension(150, 20));
		nPanel.add(tf_Username);
		// secondPanel of midle panel
		JPanel cPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		cPanel.add(new JLabel("Password:"));
		tf_Password = new JPasswordField();
		tf_Password.setPreferredSize(new Dimension(150, 20));
		cPanel.add(tf_Password);
		// third panel of middle panel
		JPanel tPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		tPanel.add(new JLabel("Show Password:"));
		cb_ShowPass = new JCheckBox();
		tPanel.add(cb_ShowPass);

		// Bottom Panel
		JPanel sPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_AddUser = new JButton("Add User");
		sPanel.add(b_AddUser);
		middlePanel.add(nPanel);
		middlePanel.add(cPanel);
		middlePanel.add(tPanel);

		mainPanel.add(topPanel, BorderLayout.NORTH);
		mainPanel.add(middlePanel, BorderLayout.CENTER);
		mainPanel.add(sPanel, BorderLayout.SOUTH);

		dialog.add(mainPanel);
		dialog.pack();
	}

	private void actionListener() {
		cb_ShowPass.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (valueChecked == false) {
					tf_Password.setEchoChar((char) 0);

					valueChecked = true;
				} else {
					tf_Password.setEchoChar('*');
					valueChecked = false;
				}
			}
		});
		tf_Password.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String user__Name = tf_Username.getText().toString();
					String passsss = tf_Password.getText().toString();
					checkUserNameExists(user__Name, readFile(login_Path));
					if (user__Name.length() > 0 && passsss.length() > 0) {

						if (checkUserNameExists(user__Name,
								readFile(login_Path))) {
							System.out.println("USER PASS::::"
									+ readFile(login_Path));
							JSONObject object = new JSONObject();
							try {
								object.put("Username", user__Name);
								object.put("Password", passsss);
								JSONArray myArray = readFile(login_Path);
								myArray.put(object);
								writeToFile(login_Path, myArray);
								System.out.println(myArray.toString());
								dialog.dispose();
							} catch (JSONException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} else {
							JOptionPane
									.showMessageDialog(null,
											"The username already exists, please use a different one and try  again!");
						}

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String user__Name = tf_Username.getText().toString();
					String passsss = tf_Password.getText().toString();
					checkUserNameExists(user__Name, readFile(login_Path));
					if (user__Name.length() > 0 && passsss.length() > 0) {

						if (checkUserNameExists(user__Name,
								readFile(login_Path))) {
							System.out.println("USER PASS::::"
									+ readFile(login_Path));
							JSONObject object = new JSONObject();
							try {
								object.put("Username", user__Name);
								object.put("Password", passsss);
								JSONArray myArray = readFile(login_Path);
								myArray.put(object);
								writeToFile(login_Path, myArray);
								System.out.println(myArray.toString());
								dialog.dispose();
							} catch (JSONException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} else {
							JOptionPane
									.showMessageDialog(null,
											"The username already exists, please use a different one and try  again!");
						}

					}
				}
			}
		});
		tf_Username.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String user__Name = tf_Username.getText().toString();
					String passsss = tf_Password.getText().toString();
					checkUserNameExists(user__Name, readFile(login_Path));
					if (user__Name.length() > 0 && passsss.length() > 0) {

						if (checkUserNameExists(user__Name,
								readFile(login_Path))) {
							System.out.println("USER PASS::::"
									+ readFile(login_Path));
							JSONObject object = new JSONObject();
							try {
								object.put("Username", user__Name);
								object.put("Password", passsss);
								JSONArray myArray = readFile(login_Path);
								myArray.put(object);
								writeToFile(login_Path, myArray);
								System.out.println(myArray.toString());
								dialog.dispose();
							} catch (JSONException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} else {
							JOptionPane
									.showMessageDialog(null,
											"The username already exists, please use a different one and try  again!");
						}

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String user__Name = tf_Username.getText().toString();
					String passsss = tf_Password.getText().toString();
					checkUserNameExists(user__Name, readFile(login_Path));
					if (user__Name.length() > 0 && passsss.length() > 0) {

						if (checkUserNameExists(user__Name,
								readFile(login_Path))) {
							System.out.println("USER PASS::::"
									+ readFile(login_Path));
							JSONObject object = new JSONObject();
							try {
								object.put("Username", user__Name);
								object.put("Password", passsss);
								JSONArray myArray = readFile(login_Path);
								myArray.put(object);
								writeToFile(login_Path, myArray);
								System.out.println(myArray.toString());
								dialog.dispose();
							} catch (JSONException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						} else {
							JOptionPane
									.showMessageDialog(null,
											"The username already exists, please use a different one and try  again!");
						}

					}
				}
			}
		});
		b_AddUser.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String user__Name = tf_Username.getText().toString();
				String passsss = tf_Password.getText().toString();
				checkUserNameExists(user__Name, readFile(login_Path));
				if (user__Name.length() > 0 && passsss.length() > 0) {

					if (checkUserNameExists(user__Name, readFile(login_Path))) {
						System.out.println("USER PASS::::"
								+ readFile(login_Path));
						JSONObject object = new JSONObject();
						try {
							object.put("Username", user__Name);
							object.put("Password", passsss);
							JSONArray myArray = readFile(login_Path);
							myArray.put(object);
							writeToFile(login_Path, myArray);
							System.out.println(myArray.toString());
							dialog.dispose();
						} catch (JSONException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					} else {
						JOptionPane
								.showMessageDialog(null,
										"The username already exists, please use a different one and try  again!");
					}

				}
			}

		});
	}

	/**
	 * This method checks whether a username already exists within the directory
	 */
	private boolean checkUserNameExists(String user__Name, JSONArray readFile) {
		boolean value = true;
		try {
			for (int i = 0; i < readFile.length(); i++) {

				JSONObject object = (JSONObject) readFile.get(i);
				if (object.get("Username").equals(user__Name)) {
					value = false;
					break;

				}

			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;

	}

	/**
	 * This methods Reads the content of the file.
	 */
	private JSONArray readFile(String login_Path) {
		String content = "";
		JSONArray array = null;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(
					login_Path)));
			String text = "";

			while ((text = reader.readLine()) != null) {
				content += text;
			}

			array = new JSONArray(content);

		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		} catch (JSONException e) {

		}
		return array;

	}

	/**
	 * Writes the array to the UserNamePassword of the admin to the file.
	 * 
	 * @param string
	 */
	private void writeToFile(String string, JSONArray array) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
					string)));
			writer.write(array.toString());
			writer.close();
		} catch (IOException e) {

		}

	}
}
