import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RemoveUserAccount {
	private String login_path;
	private JDialog dialog;
	private JTextField tf_UserName;
	private JButton b_Remove;
	private int objectPosition;

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}

	public RemoveUserAccount(String login_path) {
		this.login_path = login_path;
		gui();
		actionListener();
		dialog.pack();
		setPosition(1, dialog, null);
		dialog.show();
	}

	private void actionListener() {
		// TODO Auto-generated method stub
		b_Remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				String userName = tf_UserName.getText().toLowerCase();
				if (userName.equals("admin")) {
					JOptionPane
							.showMessageDialog(null, "Admin cant be removed");
				} else {

					JSONArray array = readFile(login_path);
					if (checkUserNameExistence(array, userName)) {
						array.remove(objectPosition);
						writeToFile(login_path, array);
					} else {
						JOptionPane.showMessageDialog(null, "No Such User!");
					}

				}

			}
		});
		tf_UserName.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_UserName.getText().toLowerCase();
					if (userName.equals("admin")) {
						JOptionPane.showMessageDialog(null,
								"Admin cant be removed");
					} else {

						JSONArray array = readFile(login_path);
						if (checkUserNameExistence(array, userName)) {
							array.remove(objectPosition);
							writeToFile(login_path, array);
						} else {
							JOptionPane
									.showMessageDialog(null, "No Such User!");
						}

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_UserName.getText().toLowerCase();
					if (userName.equals("admin")) {
						JOptionPane.showMessageDialog(null,
								"Admin cant be removed");
					} else {

						JSONArray array = readFile(login_path);
						if (checkUserNameExistence(array, userName)) {
							array.remove(objectPosition);
							writeToFile(login_path, array);
						} else {
							JOptionPane
									.showMessageDialog(null, "No Such User!");
						}

					}
				}
			}
		});
	}

	private boolean checkUserNameExistence(JSONArray array, String uName) {
		boolean value = false;
		try {
			for (int i = 0; i < array.length(); i++) {

				JSONObject object = array.getJSONObject(i);
				// System.out.println(object.toString());
				String userNameTwo = object.getString("Username").toLowerCase();
				if (uName.toLowerCase().equals(userNameTwo)) {
					objectPosition = i;
					value = true;
					break;
				}

			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return value;

	}

	public void gui() {
		dialog = new JDialog();
		dialog.setModal(true);
		JPanel panel = new JPanel(new BorderLayout());

		// North of the panel
		JPanel nPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel title = new JLabel("Remove User");
		nPanel.add(title);
		// Center of the Panel
		JPanel cPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		cPanel.add(new JLabel("Username:"));
		tf_UserName = new JTextField();
		tf_UserName.setPreferredSize(new Dimension(150, 20));
		cPanel.add(tf_UserName);
		// south panel
		JPanel sPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_Remove = new JButton("Remove");
		sPanel.add(b_Remove);

		// Adding everything to the panel
		panel.add(nPanel, BorderLayout.NORTH);
		panel.add(cPanel, BorderLayout.CENTER);
		panel.add(sPanel, BorderLayout.SOUTH);
		dialog.add(panel);

	}

	/**
	 * This methods Reads the content of the file.
	 */
	private JSONArray readFile(String login_Path) {
		String content = "";
		JSONArray array = null;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(
					login_Path)));
			String text = "";

			while ((text = reader.readLine()) != null) {
				content += text;
			}

			array = new JSONArray(content);

		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		} catch (JSONException e) {

		}
		return array;

	}

	/**
	 * Writes the array to the UserNamePassword of the admin to the file.
	 * 
	 * @param string
	 */
	private void writeToFile(String string, JSONArray array) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
					string)));
			writer.write(array.toString());
			writer.close();
		} catch (IOException e) {

		}

	}

}
