import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ExportFiles extends Thread {
	private String path;
	private String destinationPath;
	private File excel, json;
	private String fileName;

	public ExportFiles(String path, String destinationPath, String fileName) {
		this.path = path;
		// System.out.println("PATHPATH: " + path);
		this.destinationPath = destinationPath;
		// System.out.println(path);
		this.fileName = fileName;
	}

	public void run() {

		getFiles(path);
		createDirectories();
		// zipFile();
	}

	/**
	 * Initializes the files using the path
	 */
	private void getFiles(String path) {
		excel = new File(path + ".xls");
		json = new File(path + ".json");
		System.out.println("EXCEL: " + excel.getAbsolutePath());
		System.out.println("JSON: " + json.getAbsolutePath());

	}

	/**
	 * Zips and copies the files :)
	 * 
	 * @param json
	 * @param Excel
	 * @param src
	 */
	public void createDirectories() {
		File file = new File(destinationPath + "/" + fileName);
		System.out.println("DESTIONATION: " + file.getAbsolutePath());
		// file.mkdir();
		if (!file.exists()) {
			file.mkdir();
		}
		File JS = new File(file.getAbsolutePath() + "/" + fileName + ".json");

		File exc = new File(file.getAbsolutePath() + "/" + fileName + ".xls");
		System.out.println("Excel:" + exc.getAbsolutePath());
		System.out.println("JSON: " + JS.getAbsolutePath());
		try {
			exc.createNewFile();
			JS.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			copyFile(json, new File(file.getAbsolutePath() + "/" + fileName
					+ ".json"));
			copyFile(excel, new File(file.getAbsolutePath() + "/" + fileName
					+ ".xls"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * From: http://www.journaldev.com/861/4-ways-to-copy-file-in-java
	 * 
	 * @param source
	 * @param dest
	 * @throws IOException
	 */
	private void copyFile(File source, File dest) throws IOException {
		FileChannel sourceChannel = null;
		FileChannel destChannel = null;
		try {
			sourceChannel = new FileInputStream(source).getChannel();
			destChannel = new FileOutputStream(dest).getChannel();
			destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
		} finally {
			sourceChannel.close();
			destChannel.close();
		}
		System.out.println("COPIED");
	}

}
