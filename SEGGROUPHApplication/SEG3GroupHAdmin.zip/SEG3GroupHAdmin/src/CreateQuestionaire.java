import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JList;

import jxl.Workbook;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import database.QuestionaireRecord;

public class CreateQuestionaire {
	private String stage, type;
	private JDialog dialog;
	private String path;
	private DefaultListModel model;
	private JList list;
	private String jsonPath;
	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}
	public CreateQuestionaire(String type, String stage, JDialog dialog,
			String path, JList list, DefaultListModel model, String jsonPath) {
		this.stage = stage;
		this.type = type;
		this.dialog = dialog;
		this.path = path;
		this.model = model;
		this.list = list;
		this.jsonPath = jsonPath;
		setPosition(1, dialog, null);
		// This is to end the dialog :)
		// dialog.dispose();
		// System.out.println(MainFrame.FILE_PATH);
		// System.out.println(type + "  " + stage);
		if (stage.equals(new String("")) || type.equals(new String(""))) {
			System.out.println("Files Werent Created");
		} else {
			if (stage.contains("-") || type.contains("-")) {

			} else {

				QuestionaireRecord questionaireRecord = new QuestionaireRecord();
				// Need the questionaire name, I assume that the name will always be as below 
				String questionaireTitle = type + "-" + stage;
				String questionaireFileName = path + "/" + questionaireTitle + ".json";
				questionaireRecord.createRecord(questionaireTitle, type, stage);
				if(questionaireRecord.save())
				{
					// checkFileExistence(path + "/" + type);
					createFolders();
					File folder = new File(path);
					updateQuestionairesList(folder);
					// System.out.println(path);
					// writeToFile(type, stage);
					System.out.println("Questionaire Record saved");
				}
				//TODO Handle error when questionaire record cannot be saved
				dialog.dispose();
			}
		}
	}
	

	private void createFolders() {
		File jsonFile = new File(path + "/" + type + "-" + stage + ".json");
		File excelFile = new File(path + "/" + type + "-" + stage + ".xls");
		if (jsonFile.exists() && excelFile.exists()) {

			System.out.println("The files werent created");
			System.out
					.println("TO-DO: promt saying the Questionaire already exists");
		} else {
			try {
				jsonFile.createNewFile();
				WritableWorkbook workbook = Workbook.createWorkbook(excelFile);
				workbook.createSheet(type + "-" + stage, 0);
				workbook.write();
				workbook.close();
				System.out.println("Files Were Created");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (WriteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void updateQuestionairesList(File file) {
		model.removeAllElements();
		for (File entry : file.listFiles()) {
			if (entry.getName().endsWith(".json")) {
				// System.out.println(entry.getName());
				String name = entry.getName().substring(0,
						entry.getName().length() - 5);
				System.out.println(name);
				model.addElement(name);
			}
		}
		sortList(model);
		list.setModel(model);

	}

	public void sortList(DefaultListModel myModel) {
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < model.size(); i++) {
			list.add((String) model.getElementAt(i));
		}
		Collections.sort(list);
		model.removeAllElements();
		for (int i = 0; i < list.size(); i++) {
			model.addElement(list.get(i));
		}
		list.removeAll(list);
	}

	// public void writeToFile(String type, String stage) {
	// try {
	// BufferedReader reader = new BufferedReader(new FileReader(new File(
	// jsonPath)));
	// String text = "";
	// String content = "";
	// while ((text = reader.readLine()) != null) {
	// content += text;
	// }
	// reader.close();
	// System.out.println("File Content: " + content);
	// if (content.length() == 0) {
	// JSONArray array = new JSONArray();
	// JSONObject object = new JSONObject();
	// object.put("Type", type);
	// object.put("Stage", stage);
	// array.put(object);
	// BufferedWriter writer = new BufferedWriter(new FileWriter(
	// new File(jsonPath)));
	// writer.write(array.toString());
	// writer.flush();
	//
	// } else {
	// JSONArray array = new JSONArray(content);
	// JSONObject object = new JSONObject();
	// object.put("Type", type);
	// object.put("Stage", stage);
	// array.put(object);
	// BufferedWriter writer = new BufferedWriter(new FileWriter(
	// new File(jsonPath)));
	// writer.write(array.toString());
	// writer.flush();
	// }
	//
	// } catch (FileNotFoundException e) {
	//
	// } catch (IOException e) {
	//
	// } catch (JSONException e) {
	//
	// }
	//
	// }
}
