package database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public abstract class TableRecord {
	public static SQLiteJDBC sqlConnection;
	protected String databaseName;
	protected Map<String, String> columnMap = null;
	private String tableName; 

	public TableRecord(String tableName)
	{	
		this.tableName = tableName;
		columnMap = new HashMap<String, String>();
	}
	/**
	 * This method saves the table record as a row in the corresponding table.
	 * A connection will be established briefly and closed after the record is saved
	 * It's equivalent to INSERT statement in SQLite.
	 * @return true if the record was successfully saved. False if there is an error.
	 */
	public synchronized boolean save()
	{
		Boolean hasNoSQLError = false;
		Iterator<String> columnNameIterator = columnMap.keySet().iterator();
		if(columnMap.equals(null))
		{
			return false;
		}
		//Check if there are any values in the in the iterator, if there are not, return false immediately
		if(columnNameIterator.hasNext())
		{
			//Get the first key and add it to the string that contains column' names
			String firstColumnName = columnNameIterator.next();
			String columnNames = firstColumnName; 
			//Get the value of the first key and add it to the string that contains column' values
			String columnValues = "'" + columnMap.get(firstColumnName) + "'";
			
			//Put each of the key and value of each element in the map into columnNames and columnValues respectively
			while(columnNameIterator.hasNext())
			{
				String columnName = columnNameIterator.next();
				String columnValue = columnMap.get(columnName);
				if(columnValue !=null && columnValue.trim() != "")
				{
					columnNames = columnNames + ", " + columnName;
					columnValues = columnValues + ", " + "'" + columnValue + "'";
				}
			}
			String sqlCommand = "INSERT INTO " + tableName + "("+ columnNames +") " +
					"VALUES(" + columnValues + ");";
			try {
				//Connect to SQLite server, execute and terminate the connection
				executeUpdate(sqlCommand);
				hasNoSQLError = true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		}
		
		return hasNoSQLError;
	}	
	
	/**
	 * 
	 * This method creates a connection with sqlLite, whose function can be used
	 * It also will attempts to create a new connection to the default predefined database. 
	 * @param databaseName the name of the database 
	 * @throws SQLException 
	 */
	public synchronized boolean connect() throws SQLException {
		return sqlConnection.connect();
	}
	/**
	 * This method creates a connection with sqlLite , whose function can be used
	 * It also will attempts to create a new connection to a specified database. 
	 * The connection should be closed when you are done.
	 * @param databaseName the name of the database 
	 */
	public synchronized boolean connect(String databaseName) {
		this.databaseName = databaseName;
		sqlConnection = new SQLiteJDBC(databaseName);
		try {
			sqlConnection.connect(databaseName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}
	/**
	 * This method executes a specified sql command.
	 * Connection will be established to execute the statement and closed after execution finishes.
	 * @param any sql commands
	 * @return true if the command was executed without errors
	 * @throws SQLException 
	 */
	protected synchronized boolean executeCommand(String sqlCommand) throws SQLException
	{
		boolean hasNoSQLError = false;
		Connection connection = sqlConnection.getConnection();
		Statement sqlStatement = connection.createStatement();
		hasNoSQLError = sqlStatement.execute(sqlCommand);
		return hasNoSQLError;
	}
	/**
	 * This method executes a sql query and return the results.
	 * Connection will be established to execute the statement and closed after execution finishes.
	 * @param SELECT sql command
	 * @return the set of results from the query
	 * @throws SQLException 
	 */
	protected synchronized ResultSet executeQuery(String sqlCommand) throws SQLException
	{
		ResultSet resultSet = null;
		Connection connection = sqlConnection.getConnection();
		Statement sqlStatement = connection.createStatement();
		
		resultSet = sqlStatement.executeQuery(sqlCommand);
		return resultSet;
	}
	/**
	 * This method executes a specified sql command.
	 * Connection will be established to execute the statement and closed after execution finishes.
	 * @param INSERT, UPDATE and DELETE commands
	 * @return the number of rows changed from this
	 * @throws SQLException 
	 */
	protected synchronized int executeUpdate(String sqlCommand) throws SQLException
	{
		int rowAffected = 0;
		
		Connection connection = sqlConnection.getConnection();
		Statement sqlStatement = connection.createStatement();
		rowAffected = sqlStatement.executeUpdate(sqlCommand);
		return rowAffected;
	}
	/**
	 * This method closes the connection of sqlLite
	 * @return
	 */
	public synchronized void closeConnection() {
		try {
			sqlConnection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public SQLiteJDBC getSqlConnection() {
		return sqlConnection;
	}
	public void setSqlConnection(SQLiteJDBC sqlConnection) {
		this.sqlConnection = sqlConnection;
	}
	public String getDatabaseName() {
		return databaseName;
	}
	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}
	public Map<String, String> getColumnMap() {
		return columnMap;
	}
	public void setColumnMap(Map<String, String> columnMap) {
		this.columnMap = columnMap;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
}
