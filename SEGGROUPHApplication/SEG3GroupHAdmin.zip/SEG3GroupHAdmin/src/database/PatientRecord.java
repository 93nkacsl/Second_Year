package database;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientRecord extends TableRecord{
	public static String TABLE_NAME = "Patient";

	public PatientRecord() {
		super(TABLE_NAME);
	}
	/**
	 * This method create the record for patient
	 * @param name the name of the patient
	 * @param dateOfBirth the date of birth of the patient
	 * @param gender the gender of the patient Male or Female
	 * @param nationality the nationality of the patient
	 * @param illness the illness the patient has
	 * @param stage the stage of the illness in which the patient is in
	 */
	public void createRecord(String name, String dateOfBirth, String gender, String nationality, String illness, String stage) {
		columnMap.put("name", name);
		columnMap.put("dateOfBirth", dateOfBirth);
		columnMap.put("illness", illness);
		columnMap.put("stage", stage);
		columnMap.put("gender", gender);
		columnMap.put("nationality", nationality);
	}
	
	public void updateStage(String newStage, String name, String dateOfBirth) throws SQLException {
		String sqlCommand = "UPDATE TABLE " + 
							TABLE_NAME + 
							" SET stage = " + 
							"'" + newStage +"' " + 
							"WHERE name = " + "'" + name + "' " +
							"AND dateOfBirth = " + "'" + dateOfBirth + "'";
		executeUpdate(sqlCommand);
	}
	
	public ResultSet getRecords(String name, String dateOfBirth) throws SQLException {
		ResultSet results = null;
		String sqlCommand = "SELECT * FROM " + TABLE_NAME + " WHERE " + "name = " + "'" + name + "'" + " AND " + "dateOfBirth = " + "'" + dateOfBirth + "'"; 
		results = executeQuery(sqlCommand);
		return results;	
	}
}
