package database;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.StringTokenizer;

public class SQLiteJDBC {
	public static String DEFAULT_DATABASE_NAME = "questionairedb";
	private Connection connection = null;
	private String databaseName;
	private boolean isConnected = false;
	
	public SQLiteJDBC()
	{
		this.databaseName = DEFAULT_DATABASE_NAME;
	}
	
	public SQLiteJDBC(String databaseName)
	{
		this.databaseName = databaseName;
	}
	/**
	 * This method creates a connection with sqlLite, whose function can be used
	 * It also will attempts to create a new connection to the default predefined database. 
	 * @param databaseName the name of the database 
	 * @throws SQLException 
	 */
	public synchronized boolean connect() throws SQLException {
		return connect(databaseName);
	}
	/**
	 * This method connects the java program to sqlite.
	 * It will also create a database if the name does not exists
	 * @param String databaseName the name of the database to connection to
	 * @throws SQLException 
	 */
	public synchronized boolean connect(String databaseName) throws SQLException
	{
		if(!isConnected)
		{
			this.databaseName = databaseName;
			try {
				Class.forName("org.sqlite.JDBC");
				connection = DriverManager.getConnection("jdbc:sqlite:db/" + databaseName + ".db");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			System.out.println("Opened database successfully");
		}
		isConnected = true;
		return true;
	}
	
	/**
	 * This method executes command from a sqlFile
	 * @param sqlFile the file containing sql commands that will create a table
	 * @throws SQLException 
	 */
	public synchronized void executeSqlFile(File sqlFile) throws SQLException
	{
		try {
			BufferedReader sqlBufferedReader = new BufferedReader(new FileReader(sqlFile));
			String sqlCommand = "";
			String fileLine = null;
			while((fileLine = sqlBufferedReader.readLine()) !=null)
			{
				sqlCommand = sqlCommand + " "+ fileLine;
			}
			sqlBufferedReader.close();
			//Create a sql statement
			if(sqlCommand!=null)
			{
				//Create tokenizer for separating sqlcommands in a sql files
				//Because execute does not execute multiple sql commands
				StringTokenizer sqlCommandTokenizer = new StringTokenizer(sqlCommand, ";");
				connect();
				Statement sqlStatement = connection.createStatement();
				while(sqlCommandTokenizer.hasMoreTokens())
				{
					sqlStatement.execute(sqlCommandTokenizer.nextToken());
				}

				sqlStatement.close();
				close();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * This method closes the connection to the database;
	 * @throws SQLException 
	 */
	public synchronized void close() throws SQLException
	{
		if(!isConnected)
		{
			connection.close();
		}
		isConnected = false;
	}

	/**
	 * This method checks whether there is a connection to the SQLite database 
	 * @return true if there is a connection 
	 */
	public boolean isConnected()
	{
		return isConnected;
	}
	
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String currentDatabaseName) {
		this.databaseName = currentDatabaseName;
	}

}

