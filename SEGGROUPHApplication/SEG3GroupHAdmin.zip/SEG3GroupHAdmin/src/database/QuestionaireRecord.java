package database;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuestionaireRecord extends TableRecord{
	public static String TABLE_NAME = "Questionaire";
	
	public QuestionaireRecord() {
		super(TABLE_NAME);
	}
	public void createRecord(String title, String illness, String stage)
	{
		columnMap.put("title", title);
		columnMap.put("illness", illness);
		columnMap.put("stage", stage);
	}
	public ResultSet getRecords(String illness, String stage) throws SQLException
	{
		ResultSet results = null;
		if(illness != null && stage != null)
		{
			String sqlCommand = "SELECT * FROM " + TABLE_NAME + " WHERE " + "illness = " + "'" + illness + "'" + " AND " + "stage = " + "'" + stage + "'"; 
			results = executeQuery(sqlCommand);
		}
		return results;
	}
	
	public ResultSet getIllnessForPatient(String patientName, String patientDOB) throws SQLException
	{
		ResultSet results = null;
		String sqlCommand = "SELECT illness, stage " +
							"FROM " + TABLE_NAME +
							" WHERE " + "illness IN" +
							" (SELECT illness FROM " + PatientRecord.TABLE_NAME +
							" WHERE name=" + "'" + patientName  + "'" + " AND "+
								  "dateOfBirth=" + "'" + patientDOB + "'" + ")";
		results = executeQuery(sqlCommand);
		return results;
	}
	
	public void deleteRecords(String title) throws SQLException
	{
		if(title!=null)
		{
			String sqlCommand = "DELETE FROM " + TABLE_NAME +" WHERE " + "title=" + "'" + title + "'";
			executeUpdate(sqlCommand);
		}
	}
	
	public ResultSet getIllnessAndStage() throws SQLException {
		ResultSet results = null;
		String sqlCommand = "SELECT Illness, Stage FROM " + TABLE_NAME;
		results = executeQuery(sqlCommand);
		return results;
	}
	
}
