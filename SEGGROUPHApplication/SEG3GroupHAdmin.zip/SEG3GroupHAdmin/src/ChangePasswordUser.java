import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ChangePasswordUser {
	private String login_Path;
	private JDialog dialog;
	private JTextField tf_Username;
	private JPasswordField tf_PassPre, tf_PassCurrent;
	private JButton b_Change;
	private JSONArray array;
	private int objectPosition;
	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}
	public ChangePasswordUser(String login_Path) {
		this.login_Path = login_Path;
		System.out.println(login_Path);
		array = readFile(login_Path);
		System.out.println(array.toString());
		gui();
		actionListener();
		setPosition(1, dialog, null);
		dialog.show();
	}

	private void actionListener() {
		b_Change.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				String userName = tf_Username.getText().toString()
						.toLowerCase();
				String pPasswords = tf_PassPre.getText().toString()
						.toLowerCase();
				String nPasswords = tf_PassCurrent.getText().toString()
						.toLowerCase();
				if (checkLength(userName) && checkLength(pPasswords)
						&& checkLength(nPasswords)) {
					if (pPasswords.equals(nPasswords)) {
						JOptionPane
								.showMessageDialog(null,
										"The Passwords are thesame, please choose a different password and try again.");
					} else {

						if (checkUserNameExistence(array, userName, pPasswords)) {
							try {
								changePassAndWriteToFile(array, objectPosition,
										nPasswords);
								dialog.dispose();
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

						} else {

						}
					}

				}

			}

		});
		tf_PassCurrent.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub[

				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_Username.getText().toString()
							.toLowerCase();
					String pPasswords = tf_PassPre.getText().toString()
							.toLowerCase();
					String nPasswords = tf_PassCurrent.getText().toString()
							.toLowerCase();
					if (checkLength(userName) && checkLength(pPasswords)
							&& checkLength(nPasswords)) {
						if (pPasswords.equals(nPasswords)) {
							JOptionPane
									.showMessageDialog(null,
											"The Passwords are thesame, please choose a different password and try again.");
						} else {

							if (checkUserNameExistence(array, userName,
									pPasswords)) {
								try {
									changePassAndWriteToFile(array,
											objectPosition, nPasswords);
									dialog.dispose();
								} catch (JSONException ee) {
									// TODO Auto-generated catch block
									ee.printStackTrace();
								}

							} else {

							}
						}

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_Username.getText().toString()
							.toLowerCase();
					String pPasswords = tf_PassPre.getText().toString()
							.toLowerCase();
					String nPasswords = tf_PassCurrent.getText().toString()
							.toLowerCase();
					if (checkLength(userName) && checkLength(pPasswords)
							&& checkLength(nPasswords)) {
						if (pPasswords.equals(nPasswords)) {
							JOptionPane
									.showMessageDialog(null,
											"The Passwords are thesame, please choose a different password and try again.");
						} else {

							if (checkUserNameExistence(array, userName,
									pPasswords)) {
								try {
									changePassAndWriteToFile(array,
											objectPosition, nPasswords);
									dialog.dispose();
								} catch (JSONException ee) {
									// TODO Auto-generated catch block
									ee.printStackTrace();
								}

							} else {

							}
						}

					}
				}
			}
		});
		tf_PassPre.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub[

				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_Username.getText().toString()
							.toLowerCase();
					String pPasswords = tf_PassPre.getText().toString()
							.toLowerCase();
					String nPasswords = tf_PassCurrent.getText().toString()
							.toLowerCase();
					if (checkLength(userName) && checkLength(pPasswords)
							&& checkLength(nPasswords)) {
						if (pPasswords.equals(nPasswords)) {
							JOptionPane
									.showMessageDialog(null,
											"The Passwords are thesame, please choose a different password and try again.");
						} else {

							if (checkUserNameExistence(array, userName,
									pPasswords)) {
								try {
									changePassAndWriteToFile(array,
											objectPosition, nPasswords);
									dialog.dispose();
								} catch (JSONException ee) {
									// TODO Auto-generated catch block
									ee.printStackTrace();
								}

							} else {

							}
						}

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_Username.getText().toString()
							.toLowerCase();
					String pPasswords = tf_PassPre.getText().toString()
							.toLowerCase();
					String nPasswords = tf_PassCurrent.getText().toString()
							.toLowerCase();
					if (checkLength(userName) && checkLength(pPasswords)
							&& checkLength(nPasswords)) {
						if (pPasswords.equals(nPasswords)) {
							JOptionPane
									.showMessageDialog(null,
											"The Passwords are thesame, please choose a different password and try again.");
						} else {

							if (checkUserNameExistence(array, userName,
									pPasswords)) {
								try {
									changePassAndWriteToFile(array,
											objectPosition, nPasswords);
									dialog.dispose();
								} catch (JSONException ee) {
									// TODO Auto-generated catch block
									ee.printStackTrace();
								}

							} else {

							}
						}

					}
				}
			}
		});
		tf_Username.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub[

				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_Username.getText().toString()
							.toLowerCase();
					String pPasswords = tf_PassPre.getText().toString()
							.toLowerCase();
					String nPasswords = tf_PassCurrent.getText().toString()
							.toLowerCase();
					if (checkLength(userName) && checkLength(pPasswords)
							&& checkLength(nPasswords)) {
						if (pPasswords.equals(nPasswords)) {
							JOptionPane
									.showMessageDialog(null,
											"The Passwords are thesame, please choose a different password and try again.");
						} else {

							if (checkUserNameExistence(array, userName,
									pPasswords)) {
								try {
									changePassAndWriteToFile(array,
											objectPosition, nPasswords);
									dialog.dispose();
								} catch (JSONException ee) {
									// TODO Auto-generated catch block
									ee.printStackTrace();
								}

							} else {

							}
						}

					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_Username.getText().toString()
							.toLowerCase();
					String pPasswords = tf_PassPre.getText().toString()
							.toLowerCase();
					String nPasswords = tf_PassCurrent.getText().toString()
							.toLowerCase();
					if (checkLength(userName) && checkLength(pPasswords)
							&& checkLength(nPasswords)) {
						if (pPasswords.equals(nPasswords)) {
							JOptionPane
									.showMessageDialog(null,
											"The Passwords are thesame, please choose a different password and try again.");
						} else {

							if (checkUserNameExistence(array, userName,
									pPasswords)) {
								try {
									changePassAndWriteToFile(array,
											objectPosition, nPasswords);
									dialog.dispose();
								} catch (JSONException ee) {
									// TODO Auto-generated catch block
									ee.printStackTrace();
								}

							} else {

							}
						}

					}
				}
			}
		});
	}

	private void gui() {
		dialog = new JDialog();
		// The mainPanel
		JPanel mainPanel = new JPanel(new BorderLayout());
		// North of the Panel
		JPanel nPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		nPanel.add(new JLabel("Change Account Password"));

		// Center Panel
		JPanel cPanel = new JPanel(new GridLayout(3, 1));
		// Top of center panel
		JPanel cnPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));

		tf_Username = new JTextField();
		tf_Username.setPreferredSize(new Dimension(150, 20));
		cnPanel.add(new JLabel("Username:"));
		cnPanel.add(tf_Username);
		// Center of center Panel
		JPanel ccPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		tf_PassPre = new JPasswordField();
		tf_PassPre.setPreferredSize(new Dimension(150, 20));
		ccPanel.add(new JLabel("Previouse Password:"));
		ccPanel.add(tf_PassPre);
		// Bottom of center pane;
		JPanel csPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		csPanel.add(new JLabel("New Password:"));
		tf_PassCurrent = new JPasswordField();
		tf_PassCurrent.setPreferredSize(new Dimension(150, 20));
		csPanel.add(tf_PassCurrent);

		// Adding the content of the center panel
		cPanel.add(cnPanel);
		cPanel.add(ccPanel);
		cPanel.add(csPanel);

		// Bottom panel
		JPanel sPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_Change = new JButton("Change");
		sPanel.add(b_Change);
		// Adding everything to the mainPanel
		mainPanel.add(nPanel, BorderLayout.NORTH);
		mainPanel.add(cPanel, BorderLayout.CENTER);
		mainPanel.add(sPanel, BorderLayout.SOUTH);

		// Adding to dialog
		dialog.add(mainPanel);
		dialog.pack();
		dialog.setModal(true);

	}

	/**
	 * Checks the length of a string variable and return true if the langth is
	 * more than 0. It is used t check the length of the username previouse an
	 * dcurrent pass.word
	 * 
	 * @param text
	 * @return
	 */
	public boolean checkLength(String text) {
		if (text.length() > 0) {
			return true;
		} else
			return false;
	}

	/**
	 * Checks to see if the user has entered right username and password.
	 * 
	 * @param array
	 * @param uName
	 * @param pPasswords
	 * @return
	 */
	private boolean checkUserNameExistence(JSONArray array, String uName,
			String pPasswords) {
		boolean value = false;
		try {
			for (int i = 0; i < array.length(); i++) {

				JSONObject object = array.getJSONObject(i);
				// System.out.println(object.toString());
				String userNameTwo = object.getString("Username");
				String pass = object.getString("Password");
				if (userNameTwo.toLowerCase().equals(uName.toLowerCase())
						&& pPasswords.toLowerCase().equals(pass)) {
					objectPosition = i;
					value = true;
					break;
				}

			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return value;

	}

	/**
	 * This methods Reads the content of the file.
	 */
	private JSONArray readFile(String login_Path) {
		String content = "";
		JSONArray array = null;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(
					login_Path)));
			String text = "";

			while ((text = reader.readLine()) != null) {
				content += text;
			}

			array = new JSONArray(content);

		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		} catch (JSONException e) {

		}
		return array;

	}

	/**
	 * Writes the array to the UserNamePassword of the admin to the file.
	 * 
	 * @param string
	 */
	private void writeToFile(String string, JSONArray array) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
					string)));
			writer.write(array.toString());
			writer.close();
		} catch (IOException e) {

		}

	}

	private void changePassAndWriteToFile(JSONArray array, int objectPosition,
			String password) throws JSONException {
		JSONObject object = array.getJSONObject(objectPosition);
		object.put("Password", password);
		array.put(objectPosition, object);
		System.out.println(array.toString());
		writeToFile(login_Path, array);

	}
}
