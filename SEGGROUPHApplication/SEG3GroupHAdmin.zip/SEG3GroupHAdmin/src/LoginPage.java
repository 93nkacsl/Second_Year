import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginPage extends JFrame {
	private String path = System.getProperty("user.dir") + "/UserNamePassword";
	private JTextField tf_UserName;
	private JPasswordField tf_Password;
	private JButton b_Login;

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}
	public LoginPage() {
		super("Login");
		setPosition(0, null, this);
		System.out.println(path);
		gui();
		createUsernamePassFile();
		actionListener();
		setVisible(true);
	}

	private void actionListener() {
		b_Login.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				String userName = tf_UserName.getText().toString();
				String password = tf_Password.getText().toString();
				if (userName.length() > 0 && password.length() > 0) {
					if (userCheck(path + "/usernamePass.json", userName,
							password)) {
						new MainFrame(path + "/usernamePass.json")
								.setVisible(true);
					} else {

					}
				}
			}

		});
		tf_Password.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_UserName.getText().toString();
					String password = tf_Password.getText().toString();
					if (userName.length() > 0 && password.length() > 0) {
						if (userCheck(path + "/usernamePass.json", userName,
								password)) {
							new MainFrame(path + "/usernamePass.json")
									.setVisible(true);
						} else {

						}
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_UserName.getText().toString();
					String password = tf_Password.getText().toString();
					if (userName.length() > 0 && password.length() > 0) {
						if (userCheck(path + "/usernamePass.json", userName,
								password)) {
							new MainFrame(path + "/usernamePass.json")
									.setVisible(true);
						} else {

						}
					}
				}
			}
		});
		tf_UserName.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_UserName.getText().toString();
					String password = tf_Password.getText().toString();
					if (userName.length() > 0 && password.length() > 0) {
						if (userCheck(path + "/usernamePass.json", userName,
								password)) {
							new MainFrame(path + "/usernamePass.json")
									.setVisible(true);
						} else {

						}
					}
				}
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					String userName = tf_UserName.getText().toString();
					String password = tf_Password.getText().toString();
					if (userName.length() > 0 && password.length() > 0) {
						if (userCheck(path + "/usernamePass.json", userName,
								password)) {
							new MainFrame(path + "/usernamePass.json")
									.setVisible(true);
						} else {

						}
					}
				}
			}
		});
	}

	/**
	 * This method checks whether the correct username and password has been
	 * entered.
	 * 
	 * @return
	 */
	private boolean userCheck(String jsonFilePath, String userName,
			String password) {
		boolean value = false;
		System.out.println(jsonFilePath);
		File file = new File(jsonFilePath);
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String text = "";
			String content = "";
			while ((text = reader.readLine()) != null) {
				content += text;
			}
			JSONArray array = new JSONArray(content);
			for (int i = 0; i < array.length(); i++) {
				JSONObject object = (JSONObject) array.get(i);
				String uName = object.getString("Username").toLowerCase();
				String pass = object.getString("Password").toLowerCase();
				if (userName.toLowerCase().equals(uName)) {
					if (password.toLowerCase().equals(pass)) {
						value = true;
						this.dispose();
					}
					break;

				}
			}

		} catch (FileNotFoundException e) {

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return value;
	}

	/**
	 * This method creates a file to store the user name and password in.
	 */
	private void createUsernamePassFile() {
		File usernamePasswordFile = new File(path);
		if (!usernamePasswordFile.exists()) {
			usernamePasswordFile.mkdir();
			System.out.println("File created");
			File usernamePasswordJSON = new File(path + "/usernamePass.json");
			if (!usernamePasswordJSON.exists()) {
				try {
					usernamePasswordJSON.createNewFile();
					System.out.println("JSON File Created");
					initializeUsernamePassword();
				} catch (IOException e) {

				}

			} else {
				System.out.println("JSON File isnt created");
			}
		} else {
			System.out.println("Files werent created!");
		}
	}

	/**
	 * This method inserts the admin username into the file.
	 */
	private void initializeUsernamePassword() {
		JSONArray array = new JSONArray();
		JSONObject object = new JSONObject();
		try {
			object.put("Username", "Admin");
			object.put("Password", "123456");
			array.put(object);
			writeToFile(path + "/usernamePass.json", array);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Writes the array to the UserNamePassword of the admin to the file.
	 * 
	 * @param string
	 */
	private void writeToFile(String string, JSONArray array) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
					string)));
			writer.write(array.toString());
			writer.close();
		} catch (IOException e) {

		}

	}

	private void gui() {
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(3, 1));
		tf_Password = new JPasswordField();
		tf_UserName = new JTextField();
		// North of the panel
		JPanel nPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		nPanel.add(new JLabel("Username:"));
		nPanel.add(tf_UserName);
		tf_UserName.setPreferredSize(new Dimension(150, 20));
		// Center of the panel
		JPanel cPanel = new JPanel(new FlowLayout(FlowLayout.LEADING));
		cPanel.add(new JLabel("Password:"));
		cPanel.add(tf_Password);
		tf_Password.setPreferredSize(new Dimension(150, 20));
		// South of the panel
		JPanel sPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_Login = new JButton("Login");
		sPanel.add(b_Login);
		mainPanel.add(nPanel);
		mainPanel.add(cPanel);
		mainPanel.add(sPanel);
		add(new JScrollPane(mainPanel));
		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public static void main(String[] args) {
		LoginPage loginPage = new LoginPage();
		Image myImg = new ImageIcon("AdminIcon.png").getImage();
		loginPage.setIconImage(myImg);
	}

}
