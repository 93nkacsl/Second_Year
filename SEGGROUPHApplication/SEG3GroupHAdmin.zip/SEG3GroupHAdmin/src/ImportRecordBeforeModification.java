import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;

public class ImportRecordBeforeModification {
	// new ModifyPage(path, list_Questionaires.getSelectedValue()
	// .toString());
	private String path;
	private String selectedValue;
	private JDialog dialog;
	private JButton b_Yes, b_Import;
	private JLabel label;
	private JList list_Questionaires;
	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}
	public ImportRecordBeforeModification(String path, String selectedValue,
			JList list_Questionaires) {
		this.path = path;
		this.selectedValue = selectedValue;
		this.list_Questionaires = list_Questionaires;
		gui();
		
	}

	private void deleteAndRecreate() {
		File file = new File(path + "/" + selectedValue + ".json");
		file.delete();
		try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void gui() {
		dialog = new JDialog();
		setPosition(1,dialog , null);
		dialog.setModal(true);
		dialog.setTitle("Continue?");
		JPanel mainPanel = new JPanel(new BorderLayout());
		// mainPanel.setLayout();
		JPanel centerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_Yes = new JButton("Yes");

		b_Import = new JButton("Export Record");
		centerPanel.add(b_Yes);

		centerPanel.add(b_Import);
		mainPanel.add(centerPanel);
		label = new JLabel(
				"Modification will lead to loss of record, are you sure you want to contiue?");
		mainPanel.add(label, BorderLayout.NORTH);

		dialog.add(mainPanel);
		dialog.pack();
		actionListeners();
		dialog.show();
	}

	private void actionListeners() {
		b_Yes.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				dialog.dispose();
				new ModifyPage(path, selectedValue);

			}
		});

		b_Import.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (!list_Questionaires.isSelectionEmpty()) {
					System.out.println(list_Questionaires.getSelectedValue());
					System.out.println(path + "/"
							+ list_Questionaires.getSelectedValue() + ".xls");
					JFileChooser chooser = new JFileChooser();
					chooser.setDialogTitle("Select File to export");
					chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					chooser.setAcceptAllFileFilterUsed(false);
					if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
						System.out.println("getCurrentDirectory(): "
								+ chooser.getCurrentDirectory());
						System.out.println("getSelectedFile() : "
								+ chooser.getSelectedFile());
						System.out.println(path + "/"
								+ list_Questionaires.getSelectedValue()
								+ ".xls");

						File sourceFile = new File(path + "/"
								+ list_Questionaires.getSelectedValue()
								+ ".xls");
						File outputFile = new File(chooser.getSelectedFile()
								+ "/" + list_Questionaires.getSelectedValue()
								+ ".xls");
						try {
							outputFile.createNewFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("Output File:"
								+ outputFile.getPath());
						InputStream input = null;
						FileOutputStream output = null;
						try {
							input = new FileInputStream(sourceFile);
							output = new FileOutputStream(outputFile);
							byte[] buffer = new byte[1024];
							int byteRead;
							while ((byteRead = input.read(buffer)) > 0) {
								output.write(buffer, 0, byteRead);
							}
							input.close();
							output.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						dialog.dispose();
						new ModifyPage(path, selectedValue);
					} else {
						System.out.println("No Selection ");
					}
				}

			}
		});

	}
}
