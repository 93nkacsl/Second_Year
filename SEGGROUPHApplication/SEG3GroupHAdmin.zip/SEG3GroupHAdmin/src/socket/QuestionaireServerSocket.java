package socket;
import java.io.File;
import java.io.IOException;

import networkdiscovery.DatagramNetworkDiscovery;

public class QuestionaireServerSocket extends FileServerSocket
{	
	protected DatagramNetworkDiscovery datagramDiscovery;
	
	public QuestionaireServerSocket(int port, File dirForReceivingFiles,
			File dirForSendingFiles) throws IOException {
		super(port, dirForReceivingFiles, dirForSendingFiles);
		new StartDatagramServiceThread().start();
	}

	/**
	 * This method will and accept and listen to socket and any of its incoming requests
	 * @throws IOException 
	 */
	public void listentoPort() throws IOException
	{
		//If the server socket is not closed, continue to accept any client sockets
		while(!isClosed())
		{
			socket = accept();
			System.out.println("Connected to socket " +  socket.getLocalAddress() + ", port: " + socket.getPort());
			createThread(100);
		}
	}
	/**
	 * 
	 * @param maxThreadNo
	 * @throws IOException 
	 */
	public void createThread(int maxThreadNo) throws IOException
	{
		while(QuestionaireSSHandlerThread.getThreadNo()>maxThreadNo)
		{
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//Each socket is handled by a thread;
		new QuestionaireSSHandlerThread(socket, dirForReceivingFiles, dirForSendingFiles).start();
	}
	
	/**
	 * This method closes the socket and serviceManager.
	 */
	public void close() throws IOException {
		super.close();
		new StopDatagramServiceThread().start();
	}
	private class StartDatagramServiceThread extends Thread 
	{
		public void run() {
			String serviceIDString = "#QUESTIONAIRE-SERVICE";
			try {
				datagramDiscovery = new DatagramNetworkDiscovery(5000, QuestionaireServerSocket.this.getLocalPort(), serviceIDString);
				datagramDiscovery.listenPacket();
			} catch (IOException e) {
				datagramDiscovery.close();
			}
		}
	}
	private class StopDatagramServiceThread extends Thread {
		public void run() {
			datagramDiscovery.close();
			System.out.println("Datagram Network Discovery has been closed");
		}
	}
}