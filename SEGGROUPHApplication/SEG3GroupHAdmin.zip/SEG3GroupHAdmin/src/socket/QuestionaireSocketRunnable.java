package socket;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;

public class QuestionaireSocketRunnable implements Runnable {

	QuestionaireServerSocket questionaireSS;

	/**
	 * This method creates a new thread to rec
	 * eive questionaires and send
	 * answers to the client
	 * 
	 * @param port
	 *            the port this server socket will listen to
	 * @param dirForReceivingFiles
	 *            the directory where all answers will be saved
	 * @param dirForSendingFiles
	 *            the directory where all questionaires will be sent
	 */
	public QuestionaireSocketRunnable(int port, File dirForReceivingFiles,
			File dirForSendingFiles) {
		try {
			questionaireSS = new QuestionaireServerSocket(port, dirForReceivingFiles, dirForSendingFiles);
		} catch (IOException e) {
			System.out.println("Cannot open server socket");
		}
	}

	public void run() {
		try {
			System.out.println(InetAddress.getLocalHost().getHostAddress());
			System.out.println("Port Number: " + questionaireSS.getLocalPort());
			System.out.println("Starting server...");
			questionaireSS.listentoPort();

		} catch (IOException e) {
			/*
			if(!questionaireSS.isClosed())
			{
				//TODO handle this differently
				try {
					questionaireSS.close();
				} catch (IOException e1) {
					System.out.println("Unable to close server socket");
				}
			}
			*/
			System.out.println("Socket closed");
		}
	}
	
	public void close() throws IOException {
		if(questionaireSS!=null)
		{
			questionaireSS.close();
		}
	}
}
