package socket;

import java.io.File;

public class FileManager {
	public static File getFileFromDir(File dir, String fileName)
	{
		//Handle the case in which fileName is actually a file path
		if(fileName.contains("/"))
		{
			//the directory path will be everything before the file name in a file path
			int dirSeparatorIndex = fileName.lastIndexOf("/");
			String requestedDirPath = fileName.substring(0, dirSeparatorIndex);
			fileName = fileName.substring(dirSeparatorIndex + 1);
			String dirPath = dir.getName() + "/" + requestedDirPath;
			dir = new File(dirPath);
		}
		File searchedFile = new File(dir, fileName);

		return searchedFile;
	}
}
