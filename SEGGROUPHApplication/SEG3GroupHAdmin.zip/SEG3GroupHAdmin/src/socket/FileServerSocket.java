package socket;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class FileServerSocket extends ServerSocket
{
	protected Socket socket;
	protected File dirForSendingFiles;
	protected File dirForReceivingFiles;
	protected int port;
	ServerSocketHandlerThread handlerThread;
	
	/**
	 * This method create a new Questionaire Server Socket instance.
	 * Before using any method in this class listenToPort() must be implemented
	 * @param port the port the server will listen to
	 * @throws IOException
	 */
	public FileServerSocket(int port) throws IOException {
		super(port);
		this.port = port;
	}
	/**
	 * This method create a new Questionaire Server Socket instance
	 * Before using any method in this class listenToPort() must be implemented
	 * @param port the port the server will listen to
	 * @param dirForReceivingFiles the directory where files received by this socket will be saved
	 * @param dirForSendingFiles the directory where files to be sent to the client socket will be saved
	 * @throws IOException
	 */
	public FileServerSocket(int port, File dirForReceivingFiles, File dirForSendingFiles) throws IOException {
		super(port);
		this.port = port;
		this.dirForReceivingFiles = dirForReceivingFiles;
		this.dirForSendingFiles = dirForSendingFiles;
	}
	/**
	 * This method will and accept and listen to socket and any of its incoming requests.
	 * Before using any method in this class, this must be implemented.
	 * @throws IOException 
	 */
	public void listenToPort() throws IOException
	{
			try 
			{
				if(!isClosed())
				{
					socket = accept();
					//Each socket is handled by a thread;
					handlerThread = new ServerSocketHandlerThread(socket, dirForReceivingFiles, dirForSendingFiles);
					handlerThread.start();
				}
			} 
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				closeStreamAndSocket();
			}
	}
	/**
	 * This method sends a request to the socket
	 * @param request
	 * @throws IOException 
	 */
	public void sendRequest(String request) throws IOException
	{
		handlerThread.sendRequest(request);
	}
	/**
	 * This method returns the client request
	 * @return String request
	 * @throws IOException 
	 */
	public String retrieveRequest() throws IOException
	{			
		return handlerThread.retrieveRequest();
	}
	/**
	 * This method processes the client request automatically
	 * @param request the request received from the client
	 * @return any object that can be returned from processing the request
	 * @throws IOException 
	 */
	protected Object processClientRequest(String request) throws IOException 
	{
		return handlerThread.processClientRequest(request);
	}
	/**
	 * Requests a file from the client 
	 * @param fileName the name of the file(including extensions) 
	 * @return the file requested
	 * @throws IOException 
	 */
	public File requestFile(String fileName) throws IOException
	{
		return handlerThread.requestFile(fileName);
	}
	/**
	 * This method sends a file to the client 
	 * @param file the file to be sent
	 * @throws IOException 
	 */
	public void sendFile(File file) throws IOException 
	{
		handlerThread.sendFile(file);
	}
	/**
	 * This method sends a file to the client and store it in a specified directory.
	 * The client will create the directories in the directory path if they have not been created yet.
	 * The directories will be created in a parent directory specified in the client side.
	 * e.g dirPathInClient is childDir1/childDir2 and the designated folder is parentDir then the childDir1 and childDir2 will be created
	 * and a file called file1 will have the file path of parentDir/childDir1/childDir2/file1
	 */
	public void sendFile(File file, String dirPathInClient) throws IOException
	{
		handlerThread.sendFile(file, dirPathInClient);
	}
	/**
	 * This method receives file from a client.
	 * To implement this method, you must first set the directory where the file will be saved.
	 * @param dirForReceivingFile the directory where the file will be saved to
	 * @param fileName the name of the file to save. It can also be a file path
	 * @return the file received from the client
	 * @throws IOException 
	 */
	public File receiveFile(File dirForReceivingFile, String fileName) throws IOException {
		return handlerThread.receiveFile(dirForReceivingFile, fileName);
	}
	
	/**
	 * This method closes the socket's stream, socket and the current server socket
	 * @throws IOException 
	 */
	public void closeStreamAndSocket() throws IOException
	{
		try {
			if(!isClosed())
			{
				handlerThread.closeStreamAndSocket();
				close();
				System.out.println("Socket closed");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * This method returns the directory which holds files that are going to be sent to the client 
	 * @return 
	 */
	public File getDirForSendingFile() {
		return dirForSendingFiles;
	}
	/**
	 * This method sets the directory which holds files that are going to be sent to the client
	 * @param dirForSaving
	 */
	public void setDirForSendingFile(File dirForSaving) {
		this.dirForSendingFiles = dirForSaving;
	}
	/**
	 * This method returns the directory where files received by this socket will be saved
	 * @return
	 */
	public File getDirForReceivingFile() {
		return dirForReceivingFiles;
	}
	/**
	 * This method sets the directory where files received by this socket will be saved
	 * @param dirForLoading
	 */
	public void setDirForReceivingFile(File dirForLoading) {
		this.dirForReceivingFiles = dirForLoading;
	}
	
}