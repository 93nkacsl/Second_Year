package socket;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ServerSocketHandlerThread extends Thread
{
	private Socket socket;
	protected DataInputStream dataIS;
	protected DataOutputStream dataOS;
	protected File dirForSendingFiles;
	protected File dirForReceivingFiles;
	protected static int threadNo = 0;
	
	public ServerSocketHandlerThread(Socket socket, File dirForReceivingFiles, File dirForSendingFiles) throws IOException
	{
		this.socket = socket;
		dataIS = new DataInputStream(socket.getInputStream());
		dataOS = new DataOutputStream(socket.getOutputStream());
		this.dirForReceivingFiles = dirForReceivingFiles;
		this.dirForSendingFiles = dirForSendingFiles;
	}
	@Override
	public void run() {
		super.run();
		synchronized(this) {
			threadNo++;
		}
		while(!socket.isClosed()) 
		{	
			String request;
			try 
			{
				request = retrieveRequest();
				if(!request.isEmpty())
				{
					processClientRequest(request);
				}
			} 
			catch (IOException e) 
			{
				synchronized(this) 
				{
					threadNo--;
				}
			}
		}
		synchronized(this) {
			threadNo--;
			notifyAll();
		}
	}
	/**
	 * This method sends a request to the socket
	 * @param request
	 * @throws IOException 
	 */
	public void sendRequest(String request) throws IOException
	{
		dataOS.writeUTF(request);
		dataOS.flush();
	}
	/**
	 * This method returns the client request
	 * @return String request
	 * @throws IOException 
	 */
	public String retrieveRequest() throws IOException
	{			
		String request = "";
		try 
		{
			System.out.println("Retrieving request ...");

			request = dataIS.readUTF();
			System.out.println("Retrieve " + request + " COMPLETE");
		} 
		catch (IOException e) 
		{
			System.out.println("No more requests from " + socket.getInetAddress());
			socket.close();
		}
		return request;
	}
	/**
	 * This method processes the client request automatically
	 * @param request the request received from the client
	 * @return any object that can be retrieved from processing the request
	 * @throws IOException 
	 */
	protected Object processClientRequest(String request) throws IOException 
	{
		Object resultObject = null;
		System.out.println("Processing request ...");
		if(request.startsWith("#"))
		{
			String command = "";
			String commandKeyword = "";
			String commandObject  = "";
			//Commands will have pattern beginning with # and ending with : followed by an object
			Pattern commandPattern = Pattern.compile("^(#[A-Z]{1}([_-]?[A-Z]+)+[:;])");
			Matcher commandMatcher = commandPattern.matcher(request);
			if(commandMatcher.find())
			{
				command = commandMatcher.group(1);
				commandKeyword = command.substring(1, command.length()-1);
				//If there is a : at the end of the command then there will be an object or name of object associated with that command as well
				if(command.charAt(command.length()-1) == ':')
				{
					commandObject = request.substring(command.length()).trim();
				}
				
				//Process the request from the client
				if(commandKeyword.equals("SEND_FILE"))
				{
					resultObject = receiveFile(dirForReceivingFiles, commandObject);
				}
				else if(commandKeyword.equals("REQUEST_FILE"))
				{
					File requestedFile = FileManager.getFileFromDir(dirForSendingFiles, commandObject);
					sendFile(requestedFile);
				}
				else if(commandKeyword.equals("SUCCESS"))
				{
					return true;
				}
				else if(commandKeyword.equals("FAILURE"))
				{
					return false;
				}
				else
				{
					resultObject = addCustomCommands(commandKeyword, commandObject);
				}
			}
			System.out.println("Processing request: " + command + " SUCCESS" );
		}
		else {
			System.out.println(request);
			sendSuccessNotice();
		}
		return resultObject;
	}
	
	/**
	 * This method can be overwritten to handle custom commands received by the server from the port.
	 * The custom commands will be handled by processClientRequest method.
	 * @param commandKeyword: command keyword retrieved from the request
	 * @param commandObject: command object retrieved from the request
	 * @return the object that can be returned. If there are no return values, just return null
	 */
	public Object addCustomCommands(String commandKeyword, String commandObject) throws IOException
	{
		Object resultObject = null;
		System.out.println("Invalid Command");
		return resultObject;
	}
	/**
	 * Requests a file from the client 
	 * @param fileName the name of the file(including extensions) 
	 * @return the file requested
	 * @throws IOException 
	 */
	public File requestFile(String fileName) throws IOException
	{
		sendRequest("#REQUEST_FILE:" + fileName);
		String request = retrieveRequest();
		File requestedFile = (File) processClientRequest(request);
		return requestedFile;
	}	
	/**
	 * This method sends a file to the client and store it in a specified directory.
	 * The client will create the directories in the directory path if they have not been created yet.
	 * The directories will be created in a parent directory specified in the client side.
	 * e.g dirPathInClient is childDir1/childDir2 and the designated folder is parentDir then the childDir1 and childDir2 will be created
	 * and a file called file1 will have the file path of parentDir/childDir1/childDir2/file1
	 */
	public void sendFile(File file, String dirPathInClient) throws IOException
	{	
		System.out.println("Sending file " + file.getName() + "...");
		sendRequest("#SEND_FILE:" + dirPathInClient + "/" + file.getName());
		sendFileContent(file);
	}
	/**
	 * This method sends a file to the client 
	 * @param file the file to be sent
	 * @throws IOException 
	 */
	public void sendFile(File file) throws IOException 
	{
		System.out.println("Sending file " + file.getName() + "...");
		sendRequest("#SEND_FILE:" + file.getName());
		sendFileContent(file);
	}
	/**
	 * This method sends the file content to the client socket
	 * @param file the file whose content will be sent
	 * @throws IOException
	 */
	protected void sendFileContent(File file) throws IOException 
	{
		BufferedReader bufferedReader;
		bufferedReader = new BufferedReader(new FileReader(file));
		String fileLine = null;
		while((fileLine = bufferedReader.readLine())!=null)
		{
			dataOS.writeUTF(fileLine);
		}
		//Tell client that the file has been sent
		sendRequest("#COMPLETE;");
		bufferedReader.close();
		System.out.println("Sending file " + file.getName() + " COMPLETE");
		
	}
	/**
	 * This method receives file from a client.
	 * To implement this method, you must first set the directory where the file will be saved.
	 * @param dirForReceivingFile the directory where the file will be saved to
	 * @param fileName the name of the file to save. It can also be a file path
	 * @return the file received from the client
	 * @throws IOException 
	 */
	public File receiveFile(File dirForReceivingFile, String fileName) throws IOException {
		System.out.println("Receiving file:" + fileName + "...");
		//Handle the case in which fileName is actually a file path
		if(fileName.contains("/"))
		{
			//the directory path will be everything before the file name in a file path
			int dirSeparatorIndex = fileName.lastIndexOf("/");
			String requestedDirPath = fileName.substring(0, dirSeparatorIndex);
			fileName = fileName.substring(dirSeparatorIndex + 1);
			String dirPath = dirForReceivingFile.getName() + "/" + requestedDirPath;
			dirForReceivingFile = new File(dirPath);
			dirForReceivingFile.mkdirs();
		}
		
		File file = new File(dirForReceivingFile, fileName);
		//Convert the byte into a file by writing it into a specified file
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));
		String fileLine = null;
		while((fileLine = dataIS.readUTF())!=null && !fileLine.equals("#COMPLETE;"))
		{
			bufferedWriter.write(fileLine + '\n');
		}
		bufferedWriter.flush();
		bufferedWriter.close();
		sendSuccessNotice();
		System.out.println("Receiving file: " + fileName + " SUCCESS");
		return file;
	}
	public void sendFailureNotice(String failureDetail) throws IOException
	{
		sendRequest("#FAILURE: " + failureDetail);
	}
	public void sendSuccessNotice() throws IOException
	{
		sendRequest("#SUCCESS;");
	}
	/**
	 * This method closes the output and input streams as well as the connection to client socket
	 * @throws IOException
	 */
	public void closeStreamAndSocket() throws IOException
	{
		dataIS.close();
		dataOS.close();
		socket.close();
	}
	public static int getThreadNo() {
		return threadNo;
	}
	public static void setThreadNo(int threadNo) {
		ServerSocketHandlerThread.threadNo = threadNo;
	}
	
}