package socket;

import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jxl.Cell;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import database.PatientRecord;
import database.QuestionaireRecord;

public class QuestionaireSSHandlerThread extends ServerSocketHandlerThread{
	public QuestionaireSSHandlerThread(Socket socket,
			File dirForReceivingFiles, File dirForSendingFiles)
			throws IOException {
		super(socket, dirForReceivingFiles, dirForSendingFiles);
	}
	@Override
	public Object addCustomCommands(String commandKeyword, String commandObject) throws IOException {
		Object resultObject = null;
		if(commandKeyword.equals("PATIENT"))
		{
			String[] patientDetails = commandObject.split(",");
			String name = patientDetails[0].trim();
			String dateOfBirth = patientDetails[1].trim().replaceAll("-", "/");

			//patient detail in this case will have: name, dateOfBirth, illness, stage
			if(patientDetails.length==4)
			{
				String illness = patientDetails[2].trim();
				String stage = patientDetails[3].trim();
				sendQuestionaire(dirForSendingFiles, name, dateOfBirth, null, null, illness, stage);
			}
			//patient detail in this case will have: name, dateOfBirth, gender, nationality, illness, stage, 
			else if(patientDetails.length==6)
			{
				String gender = patientDetails[2].trim();
				String nationality = patientDetails[3].trim();
				String illness = patientDetails[4].trim();
				String stage = patientDetails[5].trim();
				sendQuestionaire(dirForSendingFiles, name, dateOfBirth, gender, nationality, illness, stage);
			}
		}
		
		else if(commandKeyword.equals("ANSWER"))
		{				
			try {
				String questionaireName = null;
				HashMap<String, String> answerHashMap;
				
				int fieldSeperator = commandObject.indexOf(",");
				
				questionaireName = commandObject.substring(0, fieldSeperator).trim();
				//Remove the curly brackets
				String answerHashMapString = commandObject.substring(fieldSeperator + 2, commandObject.length()-1).trim(); 
				answerHashMap = convertAnswer(answerHashMapString);
				saveAnswer(new File("questionaires"), questionaireName, answerHashMap);
				sendSuccessNotice();
			} catch (RowsExceededException e) {
				System.out.println("Row has been exceeded");
				e.printStackTrace();
			} catch (WriteException e) {
				sendFailureNotice("Cannot write into the database");
				e.printStackTrace();
			} catch (BiffException e) {
				e.printStackTrace();
			}
		}
		else if(commandKeyword.equals("REQUEST-ILLNESS-INFO"))
		{
			sendIllnessInfo();
		}
		else if(commandKeyword.equals("REQUEST-PATIENT-ILLNESS"))
		{
			String[] patientDetails = commandObject.split(", ");

			if(patientDetails.length>=2)
			{
				String name = patientDetails[0];
				String dateOfBirth = patientDetails[1];
				sendPatientIllness(name, dateOfBirth);
				try {
					String request = retrieveRequest();
					return  (Boolean) processClientRequest(request);
				} 
				catch (IOException e) 
				{
					System.out.println("There is something wrong with the connection");
					e.printStackTrace();
				}
			}
		}
		return resultObject;
	}
	/**
	 * This method sends the questionaire to a patient, whose record is already stored the database
	 * @param name the name of the patient
	 * @param dateOfBirth date of birth of the patient in format (dd/mm/yyyy)
	 * @throws IOException cannot send data to the client
	 */
	protected void sendQuestionaire(File dirForSendingFile, String name, String dateOfBirth, String gender, String nationality, String illness, String stage) throws IOException
	{
		PatientRecord patientRecord = new PatientRecord();
		String recordedIllness = null;
		String recordedStage = null;
		try {
			ResultSet patients = patientRecord.getRecords(name, dateOfBirth);
			if(patients.next())
			{
				//TODO update patient stage
				recordedIllness = patients.getString("illness");
				recordedStage = patients.getString("stage");
			}
			else{
				synchronized(this)
				{
					patientRecord.createRecord(name, dateOfBirth, gender, nationality, illness, stage);
					patientRecord.save();
				}
				System.out.println("New patient record saved");
				recordedIllness = illness;
				recordedStage = stage;
			}
			QuestionaireRecord questionaireRecord = new QuestionaireRecord();
			ResultSet questionaires = questionaireRecord.getRecords(recordedIllness, recordedStage);
			if(questionaires.next())
			{
				String title = questionaires.getString("title");
				File questionaireFile = new File(dirForSendingFiles, title +".json");
				if(questionaireFile.exists())
				{
					sendFile(questionaireFile);
				}
				else
				{
					sendFailureNotice("Cannot find the questionaire requested associated to this illness and stage");
				}
			}
		} catch (SQLException e) {
			sendFailureNotice("Cannot save patient's details to the database");
		}
	}
	/**
	 * This method send the illness and stage in hashmap format to the android application
	 * @throws IOException 
	 */
	public void sendIllnessInfo() throws IOException
	{
		QuestionaireRecord questionaireRecord = new QuestionaireRecord();
		try {
			ResultSet results = questionaireRecord.getIllnessAndStage();
			HashMap<String,ArrayList<String>> illnessHashMap = new HashMap<String, ArrayList<String>>();
			while(results.next())
			{
				String illness = results.getString("Illness");
				String stage = results.getString("Stage");
				ArrayList<String> stageArrayList = illnessHashMap.get(illness);
				if(stageArrayList == null)
				{
					stageArrayList = new ArrayList<String>();
				}
				stageArrayList.add(stage);
				illnessHashMap.put(illness, stageArrayList);
			}
			String request = "#SEND-ILLNESS-INFO: " + illnessHashMap.toString();
			sendRequest(request);
		} 
		catch (SQLException e) 
		{
			sendFailureNotice("Cannot access the database.");
			e.printStackTrace();
		}
	}
	
	/**
	 * This method send the list of illness and stage in hashmap format to the android application 
	 * @throws IOException 
	 */
	public void sendPatientIllness(String name, String dateOfBirth) throws IOException
	{
		QuestionaireRecord QuestionaireRecord = new QuestionaireRecord();
		ResultSet results = null;
		try {
			results = QuestionaireRecord.getIllnessForPatient(name, dateOfBirth);
			if(results!=null)
			{
				HashMap<String,ArrayList<String>> illnessHashMap = new HashMap<String, ArrayList<String>>();
				while(results.next())
				{
					String illness = results.getString("illness");
					String stage = results.getString("stage");
					ArrayList<String> stageArrayList = illnessHashMap.get(illness);
					if(stageArrayList == null)
					{
						stageArrayList = new ArrayList<String>();
					}
					stageArrayList.add(stage);
					illnessHashMap.put(illness, stageArrayList);
				}
				String request = "#SEND-PATIENT-ILLNESS: " + illnessHashMap.toString();
				sendRequest(request);
			}
			else
			{
				sendFailureNotice("Cannot find the patient details in the database");
			}
		} catch (SQLException e) {
			sendFailureNotice("Cannot access the database.");
			e.printStackTrace();
		}
	}
	
	/**
	 * This method retrieves answer from an android client and stores it directly in a xls file
	 * @param questionaireName the name of the questionaire
	 * @param answerData the answer sent from the client
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws BiffException 
	 * @throws IOException 
	 */
	public synchronized void saveAnswer(File dirForSavingAnswer, String questionaireName, HashMap<String,String> answerHashMap) throws RowsExceededException, WriteException, BiffException, IOException
	{
		File answerExcelFile = new File(dirForSavingAnswer, questionaireName + ".xls");
		if(!answerExcelFile.exists())
		{
			sendFailureNotice("Cannot find the answer file associated with this questionaire on the server");
		}
		else
		{
			try {
				WorkbookSettings wbSettings = new WorkbookSettings();
				Workbook existingWorkBook = Workbook.getWorkbook(answerExcelFile);
				WritableWorkbook workBook = Workbook.createWorkbook(answerExcelFile, existingWorkBook);
				WritableSheet sheet = null;
				int sheetNumber = workBook.getNumberOfSheets();
				//If there are more than 1000000 entries in the sheet then put data in a new sheet
				if(workBook.getSheet(sheetNumber-1).getRows()>1000000)
				{
					workBook.createSheet("Patient Answers", sheetNumber);
					//Because a new sheet has just been created, create a new sheet with index sheet number minus 1
					sheet = workBook.getSheet(sheetNumber-1);
					//Copy the first row which contains the question of the first sheet to the other sheet
					Cell[] questionRow = workBook.getSheet(0).getRow(0);
					for(int i = 0; i<questionRow.length;i++)
					{
						sheet.addCell((WritableCell) questionRow[i]);
					}
				}
				else
				{
					sheet = workBook.getSheet(0);
				}
				
				int sheetTotalRow = sheet.getRows();
				int rowNumber = 1;
				if(sheetTotalRow != 0)
				{
					rowNumber = sheetTotalRow;
				}
				sheet.insertRow(rowNumber);	
				for(int i = 1; i<=answerHashMap.size();i++)
				{
					WritableCellFormat cellFormat = new WritableCellFormat();
					String answerValue =  answerHashMap.get(Integer.toString(i));
					Label label = new Label(i-1, rowNumber, answerValue);
					sheet.addCell(label);
				}
				workBook.write();
				workBook.close();
			} catch (IOException e) {
				System.out.println("Cannot find excel file");
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * This method converts the answer string into a hashmap
	 * @param answerHashMapString the string representing the answer hash map sent from the android
	 * @return a hashmap containing all of the answers in the answer string
	 */
	protected HashMap<String, String> convertAnswer(String answerHashMapString)
	{
		Pattern answerPattern = Pattern.compile("([\\w\\-\\s]+=)((\\[([\\w\\s\\-\\/\\,])+\\])|([\\w\\/\\-\\s])+)");
		Matcher matcher = answerPattern.matcher(answerHashMapString);
		HashMap<String,String> answerHashMap = new HashMap<String,String>();
		while(matcher.find())
		{
			String answerString = matcher.group();
			int equalSignIndex = answerString.indexOf("=");
			String answerKey = answerString.substring(0, equalSignIndex ).trim();
			String answerValue = answerString.substring(equalSignIndex + 1).trim();
			//Just take off the [ ] of the bracket
			if(answerValue.startsWith("[") && answerValue.endsWith("]"))
			{
				answerValue = answerValue.substring(1,answerValue.length()-1);
			}
			answerHashMap.put(answerKey, answerValue);
		}
		return answerHashMap;
	}
}
