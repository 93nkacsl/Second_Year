import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class UserServices {
	JDialog dialog;
	String login_Path;
	JButton b_AddUser, b_ChangePasswordUserName, b_RemoveUser;

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}

	public UserServices(String login_Path) {
		this.login_Path = login_Path;
		System.out.println(login_Path);
		gui();
		actionListener();
		setPosition(1, dialog, null);
		dialog.show();
	}

	private void gui() {
		dialog = new JDialog();
		dialog.setModal(true);
		dialog.setTitle("Modify User Accounts");
		JPanel mainPanel = new JPanel(new GridLayout(3, 1));
		// Top Panel
		JPanel nPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_AddUser = new JButton("Add user");
		nPanel.add(b_AddUser);

		// center Panel
		JPanel cPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_ChangePasswordUserName = new JButton("Modify User Details");
		cPanel.add(b_ChangePasswordUserName);
		// South Panel
		JPanel sPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_RemoveUser = new JButton("Remove user");
		sPanel.add(b_RemoveUser);
		// Adding everything to the main panel
		mainPanel.add(nPanel);
		mainPanel.add(cPanel);
		mainPanel.add(sPanel);
		dialog.add(mainPanel);
		dialog.pack();

	}

	private void actionListener() {
		b_AddUser.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				new AddUser(login_Path);
			}
		});
		b_ChangePasswordUserName.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				new ChangePasswordUser(login_Path);
			}
		});
		b_RemoveUser.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				// TODO Auto-generated method stub
				new RemoveUserAccount(login_Path);

			}
		});

	}
}
