import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Box.Filler;
import javax.xml.soap.Text;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ModifyQuestion {

	private String path;
	private int position;
	private JDialog dialog;
	// From Other Project
	private String file_Path = null;
	private JRadioButton rb_SingleChoice, rb_MultipleChoice, rb_OpenEnded,
			rb_Date, rb_Numerical;
	private ButtonGroup bg_Group;
	private JList list_Answers;
	private DefaultListModel model;
	private ArrayList<String> answers = new ArrayList<String>();
	private JButton b_Add, b_Remove, b_Save;
	private JTextField tf_AnswerInput, tf_QuestionInput;
	private JSONArray array;
	private JSONObject object;

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}

	public ModifyQuestion(String path, int position, DefaultListModel model,
			JList list_Questionaire) {
		this.path = path;
		this.position = position;
		System.out.println(path);

		gui();
		getObject();
		readFile();
		setQuestion(position);
		setQuestionType();
		actionListener();
		setPosition(1, dialog, null);
		dialog.show();

	}

	/**
	 * Gets the JSONObject for that particular project.
	 */
	private void getObject() {
		try {
			array = new JSONArray(readFile());
			object = (JSONObject) array.get(position);
		} catch (JSONException e) {

		}

	}

	private void setQuestionType() {

		try {

			String type = object.getString("Question_Type");
			if (type.equals("Single Choice")) {

				rb_SingleChoice.setSelected(true);
				fillArray();
			}
			if (type.equals("Multiple Choice")) {
				rb_MultipleChoice.setSelected(true);
				fillArray();
			}
			if (type.equals("Open Ended")) {
				rb_OpenEnded.setSelected(true);
				list_Answers.setEnabled(false);
				b_Add.setEnabled(false);
				b_Remove.setEnabled(false);
				tf_AnswerInput.setText("");
				tf_AnswerInput.setEnabled(false);
			}
			if (type.equals("Date")) {
				rb_Date.setSelected(true);
				list_Answers.setEnabled(false);
				b_Add.setEnabled(false);
				b_Remove.setEnabled(false);
				tf_AnswerInput.setText("");
				tf_AnswerInput.setEnabled(false);
			}
			if (type.equals("Numerical")) {
				rb_Numerical.setSelected(true);
				list_Answers.setEnabled(false);
				b_Add.setEnabled(false);
				b_Remove.setEnabled(false);
				tf_AnswerInput.setText("");
				tf_AnswerInput.setEnabled(false);
			}
		} catch (JSONException e) {

		}

	}

	private void fillArray() {
		try {
			JSONArray list = (JSONArray) object.get("Answers");
			System.out.println(list);
			model.removeAllElements();
			for (int i = 0; i < list.length(); i++) {
				model.addElement(list.get(i));
			}
			list_Answers.setModel(model);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private String readFile() {
		String content = "";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(new File(
					path)));
			String text = null;

			while ((text = reader.readLine()) != null) {
				content += text;

			}
			reader.close();

		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		}
		return content;
	}

	private void setQuestion(int position) {
		try {

			tf_QuestionInput.setText(object.get("Question") + "");

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void gui() {
		dialog = new JDialog();
		dialog.setTitle("Add Question");
		dialog.setModal(true);
		// From Other Project
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());

		// this.path = path;
		// top of the page
		JPanel nPanel = new JPanel(new BorderLayout());
		// top of the north panel
		JPanel nNPanel = new JPanel(new GridLayout());
		nNPanel.add(new JLabel("Question:"));
		tf_QuestionInput = new JTextField();
		// tf_QuestionInput.setSize(20, 200);
		nNPanel.add(tf_QuestionInput);

		// bottom of north panel
		JPanel nSPanel = new JPanel();
		nSPanel.setLayout(new FlowLayout());
		nSPanel.add(new JLabel("Select Type: "));
		// The radioButtons and the Radio Buttons Group
		bg_Group = new ButtonGroup();
		rb_SingleChoice = new JRadioButton("Single Choice", true);
		bg_Group.add(rb_SingleChoice);
		rb_MultipleChoice = new JRadioButton("Multiple Choice");
		bg_Group.add(rb_MultipleChoice);
		rb_OpenEnded = new JRadioButton("Open Ended");
		bg_Group.add(rb_OpenEnded);
		rb_Date = new JRadioButton("Date");
		bg_Group.add(rb_Date);
		rb_Numerical = new JRadioButton("Numerical");
		bg_Group.add(rb_Numerical);
		nSPanel.add(rb_SingleChoice);
		nSPanel.add(rb_MultipleChoice);
		nSPanel.add(rb_OpenEnded);
		nSPanel.add(rb_Date);
		nSPanel.add(rb_Numerical);
		nPanel.add(nSPanel, BorderLayout.SOUTH);
		nPanel.add(nNPanel, BorderLayout.CENTER);

		// Center of the Panel
		JPanel cPanel = new JPanel();
		cPanel.setLayout(new BorderLayout());
		JLabel title = new JLabel("List of Possible answers");
		title.setHorizontalAlignment(SwingConstants.CENTER);
		cPanel.add(title, BorderLayout.NORTH);
		// center of center panel
		JPanel cCPanel = new JPanel();
		cPanel.add(cCPanel, BorderLayout.CENTER);
		cCPanel.setLayout(new GridLayout(1, 2));

		// //Left of the center panel
		JPanel cCLPanel = new JPanel();
		cCLPanel.setLayout(new GridLayout(3, 1));
		JPanel cCLTPanel = new JPanel(new GridLayout(1, 2));
		cCLTPanel.add(new JLabel("Input Answer: "));

		tf_AnswerInput = new JTextField();
		cCLTPanel.add(tf_AnswerInput);
		b_Add = new JButton("Add Answer");
		b_Remove = new JButton("Remove answer");
		cCLPanel.add(cCLTPanel);
		cCLPanel.add(b_Add);
		cCLPanel.add(b_Remove);
		cCPanel.add(cCLPanel);

		// //right of center panel
		model = new DefaultListModel();
		list_Answers = new JList(model);
		list_Answers.setListData(answers.toArray());
		cCPanel.add(new JScrollPane(list_Answers));

		// bottom of the panel

		JPanel sPanel = new JPanel();
		b_Save = new JButton("Save");
		sPanel.add(b_Save);

		// adding everything to the mainpanel
		mainPanel.add(nPanel, BorderLayout.NORTH);
		mainPanel.add(cPanel, BorderLayout.CENTER);
		mainPanel.add(sPanel, BorderLayout.SOUTH);
		// adding the mainPanel
		dialog.add(mainPanel);
		dialog.pack();

	}

	/**
	 * Add the Action listeners on to the widgets
	 */
	private void actionListener() {
		b_Add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (model.size() == 6) {
					JOptionPane.showMessageDialog(null,
							"Max number of answers",
							"6 is the maximmum numbr of answers",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					if (tf_AnswerInput.getText().length() > 0) {
						model.addElement(new String(tf_AnswerInput.getText()));
						list_Answers.setModel(model);
						tf_AnswerInput.setText("");

					}
				}

			}
		});
		b_Remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (!(list_Answers.getSelectedValue() == null)) {
					model.removeElement(list_Answers.getSelectedValue());
					list_Answers.setModel(model);
				}

			}

		});
		rb_Date.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				disableEnable(false);
				model.removeAllElements();
				list_Answers.setModel(model);

			}
		});
		rb_OpenEnded.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				disableEnable(false);
				model.removeAllElements();
				list_Answers.setModel(model);
			}
		});
		rb_Numerical.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				disableEnable(false);
				model.removeAllElements();
				list_Answers.setModel(model);
			}
		});
		rb_SingleChoice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				disableEnable(true);
			}
		});
		rb_MultipleChoice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				disableEnable(true);
			}
		});
		b_Save.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (tf_QuestionInput.getText().length() > 0) {
					object = null;
					object = new JSONObject();
					try {
						if (rb_SingleChoice.isSelected()) {

							object.put("Question", tf_QuestionInput.getText()
									.toString());
							object.put("Question_Type", "Single Choice");
							object.put("Answers", model.toArray());
							System.out.println(object.toString());
							writeToFile(array, object, position);

						}
						if (rb_MultipleChoice.isSelected()) {
							object.put("Question", tf_QuestionInput.getText()
									.toString());
							object.put("Question_Type", "Multiple Choice");
							object.put("Answers", model.toArray());
							System.out.println(object.toString());
							writeToFile(array, object, position);
						}
						if (rb_Date.isSelected()) {
							object.put("Question", tf_QuestionInput.getText()
									.toString());
							object.put("Question_Type", "Date");
							System.out.println(object.toString());
							writeToFile(array, object, position);
						}
						if (rb_Numerical.isSelected()) {
							object.put("Question", tf_QuestionInput.getText()
									.toString());
							object.put("Question_Type", "Numerical");
							System.out.println(object.toString());
							writeToFile(array, object, position);
						}
						if (rb_OpenEnded.isSelected()) {
							object.put("Question", tf_QuestionInput.getText()
									.toString());
							object.put("Question_Type", "Open Ended");
							System.out.println(object.toString());
							writeToFile(array, object, position);
						}
					} catch (JSONException e) {

					}
				}

			}

		});

	}

	private void writeToFile(JSONArray array, JSONObject object, int position) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
					path)));
			array.put(position, object);
			System.out.println(array.toString());
			writer.write(array.toString());
			writer.close();
			dialog.dispose();
		} catch (IOException e) {
			System.out.println("ERROR");
		} catch (JSONException e) {
			System.out.println("ERROR");
		}
	}

	/**
	 * Disables some widgets depending on the question type
	 * 
	 * @param value
	 */
	private void disableEnable(boolean value) {
		b_Add.setEnabled(value);
		b_Remove.setEnabled(value);
		list_Answers.setEnabled(value);
		tf_AnswerInput.setEnabled(value);
	}

}
