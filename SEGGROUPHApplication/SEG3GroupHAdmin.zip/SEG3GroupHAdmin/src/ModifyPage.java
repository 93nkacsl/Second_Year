import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.CellFormat;
import jxl.format.Colour;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ModifyPage {
	private String path, selectedValue;
	private JList list_Questions;
	private DefaultListModel model;
	private JButton b_Add, b_Modify, b_remove;
	private JDialog dialog;
	private ArrayList<String> array_Questions;

	/**
	 * This method updates the list of questions within the questionnaire :)
	 */
	private void updateListOfQuestions() {
		File file = new File(path + "/" + selectedValue + ".json");
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			System.out.println(file.getPath());
			String text = null;
			String content = "";
			while ((text = reader.readLine()) != null) {
				content += text;
			}
			JSONArray array = new JSONArray(content);
			System.out.println(array.length());
			model.removeAllElements();
			for (int i = 1; i <= array.length(); i++) {
				model.addElement("Question " + i);
			}
			list_Questions.setModel(model);
		} catch (FileNotFoundException e) {

		} catch (IOException e) {

		} catch (JSONException e) {

		}
	}

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}

	public ModifyPage(String path, String selectedValue) {

		this.path = path;
		this.selectedValue = selectedValue;
		System.out.println("Path: " + path);
		System.out.println("SelectedValue: " + selectedValue);

		gui();
		updateListOfQuestions();
		actionListeners();
		array_Questions = new ArrayList<String>();
		// END
		setPosition(1, dialog, null);
		dialog.show();
	}

	private void gui() {
		System.out.println("GUI");
		dialog = new JDialog();
		dialog.setTitle("Modify Questionaire");
		dialog.setLocationRelativeTo(null);

		JPanel mainPanel = new JPanel(new GridLayout(0, 2));
		// Widgets initialize
		JPanel leftPanel = new JPanel(new GridLayout(3, 1));
		JPanel nPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_Add = new JButton("Add");
		nPanel.add(b_Add);

		JPanel cPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_Modify = new JButton("Modify");
		cPanel.add(b_Modify);

		JPanel sPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		b_remove = new JButton("Remove");
		sPanel.add(b_remove);

		leftPanel.add(nPanel);
		leftPanel.add(cPanel);
		leftPanel.add(sPanel);
		dialog.setModal(true);
		model = new DefaultListModel();
		list_Questions = new JList(model);
		mainPanel.add(new JScrollPane(leftPanel));
		mainPanel.add(new JScrollPane(list_Questions));

		// adding the mainpanel
		dialog.add(mainPanel);
		dialog.pack();

	}

	private void actionListeners() {
		b_Add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new AddQuestion(path, selectedValue, list_Questions, model);

			}
		});
		b_Modify.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {

				if (!list_Questions.isSelectionEmpty()) {
					new ModifyQuestion(path + "/" + selectedValue + ".json",
							list_Questions.getSelectedIndex(), model,
							list_Questions);
				}

			}
		});

		b_remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (!list_Questions.isSelectionEmpty()) {
					removeQuestion(list_Questions.getSelectedIndex());
				}

			}
		});
		dialog.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent e) {
				String questionaireTitle = path + "/" + selectedValue.trim();
				// put the name and date of birth field in the questionaire
				// first.
				ArrayList<String> questionStringArray = new ArrayList<String>();
				// questionStringArray.add("Name");
				// questionStringArray.add("Date Of Birth");
				questionStringArray.addAll(getQuestions(questionaireTitle
						+ ".json"));
				writeQuestionToExcel(questionStringArray, new File(
						questionaireTitle + ".xls"));
			}

			@Override
			public void windowClosed(WindowEvent e) {
			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}
		});

	}

	public ArrayList<String> getQuestions(String path) {
		array_Questions.clear();
		File file = new File(path);
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String txt = null;
			String content = "";
			while ((txt = reader.readLine()) != null) {
				content += txt;
			}
			reader.close();
			if (content.length() > 0) {
				JSONArray array = new JSONArray(content);
				for (int i = 0; i < array.length(); i++) {
					JSONObject obj = array.getJSONObject(i);
					String q = obj.getString("Question");
					array_Questions.add(q);
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return array_Questions;
	}

	public void writeQuestionToExcel(ArrayList<String> questions, File excelFile) {
		if (questions.size() > 0 && excelFile.exists()) {
			try {
				Workbook workBook = Workbook.getWorkbook(excelFile);
				WritableWorkbook writableWorkBook = Workbook.createWorkbook(
						excelFile, workBook);
				WritableSheet sheet1 = writableWorkBook.getSheet(0);
				int questionRow = 0;
				sheet1.removeRow(questionRow);
				sheet1.insertRow(questionRow);
				// Put the question inside the 1st row of the excel file.
				for (int i = 0; i < questions.size(); i++) {
					WritableCellFormat questionCellFormat = new WritableCellFormat();
					questionCellFormat.setBackground(Colour.YELLOW);
					Label questionLabel = new Label(i, questionRow,
							questions.get(i), questionCellFormat);
					sheet1.addCell(questionLabel);
				}
				writableWorkBook.write();
				writableWorkBook.close();
			} catch (IOException e) {
				System.out
						.println("A problem occurred while trying to write or read from the questionaire excel file");
			} catch (WriteException e) {
				System.out
						.println("A problem occurred while trying to write from the questionaire excel file");
				e.printStackTrace();
			} catch (BiffException e) {
				System.out
						.println("A problem occurred while trying the read the excel file");
			}
		}
	}

	private void removeQuestion(int selectedIndex) {
		File file = new File(path + "/" + selectedValue + ".json");
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			System.out.println(file.getPath());
			String text = null;
			String content = "";
			while ((text = reader.readLine()) != null) {
				content += text;
			}
			JSONArray array = new JSONArray(content);
			array.remove(selectedIndex);
			model.removeAllElements();
			for (int i = 1; i <= array.length(); i++) {
				model.addElement("Question " + i);
			}
			list_Questions.setModel(model);
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer.write(array.toString());
			writer.close();
			System.out.println(array.toString());
		} catch (FileNotFoundException e) {
			System.out
					.println("The questionaire excel file being accessed cannot be found");
		} catch (IOException e) {
			System.out
					.println("A problem occurred while trying to write or read from the file");
		} catch (JSONException e) {
			System.out.println("There is a problem with the JSON");
		}

	}

}
