import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import socket.QuestionaireSocketRunnable;
import database.QuestionaireRecord;
import database.SQLiteJDBC;
import database.TableRecord;

public class MainFrame extends JFrame {

	// Ramiz Code
	private JButton b_Add, b_Mod, b_Remove;
	private JList list_Questionaires;
	private DefaultListModel model;
	private JMenu m_File, m_About, m_Help;
	private JMenuItem mi_Import, mi_Export, mi_About, mi_Help, mi_ExportRecord,
			mi_UserServices;
	// Amir's The widgets on the JDialog
	private JButton b_Create;

	private JTextField textField_Type, textField_Stage;
	private JDialog dialog;
	private String path = System.getProperty("user.dir") + "/questionaires";
	private String json_File_path = System.getProperty("user.dir")
			+ "/JSON.json";
	private File file_Questionaire;
	// Login file details
	String login_Path;
	private QuestionaireSocketRunnable questionaireSocketRunnable;

	/**
	 * This methods Checks Whether the Questionnaire folder exists within the
	 * directory.
	 */
	private void checkFileExistence() {
		file_Questionaire = new File(path);
		// File jsonFile = new File(jsonQuestionairesPatth);
		if (file_Questionaire.exists()) {
			updateQuestionairesList(file_Questionaire);

		} else {
			file_Questionaire.mkdir();
		}

	}

	private void checkJSONFileExistence() {
		File file = new File(json_File_path);
		if (file.exists()) {

		} else {
			try {
				file.createNewFile();

			} catch (IOException e) {

			}
		}
	}

	private void setPosition(int i, Dialog dialog, JFrame frame) {
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		if (i == 0) {
			frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
					dim.height / 2 - frame.getSize().height / 2);
		}
		if (i == 1) {
			dialog.setLocation(dim.width / 2 - dialog.getSize().width / 2,
					dim.height / 2 - dialog.getSize().height / 2);
		}

	}

	public MainFrame(String login_path) {

		super("Administration Application of Group H");
		setPosition(0, null, this);
		Image myImg = new ImageIcon("AdminIcon.png").getImage();
		this.setIconImage(myImg);
		this.login_Path = login_path;
		// If the database does not exist then create a new database
		if (!new File("db/" + SQLiteJDBC.DEFAULT_DATABASE_NAME + ".db")
				.exists()) {
			SQLiteJDBC sqlJDBC = new SQLiteJDBC();
			try {
				sqlJDBC.executeSqlFile(new File(
						"sql/createQuestionaireTables.sql"));
			} catch (SQLException e) {
				// TODO
				System.out.println("Cannot create sqld tables");
				e.printStackTrace();
			}
		}
		try {
			TableRecord.sqlConnection = new SQLiteJDBC();
			TableRecord.sqlConnection.connect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Run the socket on start
		File questionaireFolder = new File("questionaires");
		File answerFolder = new File("questionaires");
		questionaireSocketRunnable = new QuestionaireSocketRunnable(0,
				questionaireFolder, answerFolder);
		new Thread(questionaireSocketRunnable).start();
		gui();
		menuBar();
		actionListeners();
		checkFileExistence();
		checkJSONFileExistence();
	}

	private void actionListeners() {
		// Amir's Code
		b_Add.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Amir's Code Dialog box
				dialog = new JDialog();
				dialog.setTitle("Select Stage and Type");
				dialog.setLocationRelativeTo(null);
				dialog.setLayout(new GridLayout(3, 1));
				JPanel nPanel = new JPanel(new GridLayout(1, 2));
				JPanel cPanel = new JPanel(new GridLayout(1, 2));

				nPanel.add(new JLabel("Type:"));
				cPanel.add(new JLabel("Stage:"));
				nPanel.add(textField_Type);
				cPanel.add(textField_Stage);
				dialog.add(nPanel);
				dialog.add(cPanel);

				dialog.add(b_Create);
				dialog.setModal(true);
				dialog.pack();
				dialog.show();

			}
		});
		b_Create.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				CreateQuestionaire a = new CreateQuestionaire(textField_Type
						.getText(), textField_Stage.getText(), dialog, path,
						list_Questionaires, model, json_File_path);
				textField_Stage.setText("");
				textField_Type.setText("");

			}
		});
		b_Remove.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if (!list_Questionaires.isSelectionEmpty()) {
					System.out.println("Files Were Deleted");
					String questionaireFilePath = path + "\\"
							+ list_Questionaires.getSelectedValue().toString()
							+ ".json";
					File jsonFile = new File(questionaireFilePath);
					String answerFilePath = path + "\\"
							+ list_Questionaires.getSelectedValue().toString()
							+ ".xls";
					File excelFile = new File(answerFilePath);
					System.out.println();
					jsonFile.delete();
					excelFile.delete();
					QuestionaireRecord questionaireRecord = new QuestionaireRecord();
					try {
						questionaireRecord.deleteRecords(list_Questionaires
								.getSelectedValue().toString());
						System.out.println("Questionaire Record deleted");
					} catch (SQLException e1) {
						System.out
								.println("Cannot delete record from the Database");
					}
					updateQuestionairesList(file_Questionaire);

				} else {

				}
			}

		});
		b_Mod.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (!list_Questionaires.isSelectionEmpty()) {
					new ImportRecordBeforeModification(path, list_Questionaires
							.getSelectedValue().toString(), list_Questionaires);

				}
			}
		});
		mi_ExportRecord.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (!list_Questionaires.isSelectionEmpty()) {
					System.out.println(list_Questionaires.getSelectedValue());
					System.out.println(path + "/"
							+ list_Questionaires.getSelectedValue() + ".xls");
					JFileChooser chooser = new JFileChooser();
					chooser.setDialogTitle("Select File to export");
					chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					chooser.setAcceptAllFileFilterUsed(false);
					if (chooser.showOpenDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) {
						System.out.println("getCurrentDirectory(): "
								+ chooser.getCurrentDirectory());
						System.out.println("getSelectedFile() : "
								+ chooser.getSelectedFile());
						System.out.println(path + "/"
								+ list_Questionaires.getSelectedValue()
								+ ".xls");

						File sourceFile = new File(path + "/"
								+ list_Questionaires.getSelectedValue()
								+ ".xls");
						File outputFile = new File(chooser.getSelectedFile()
								+ "/" + list_Questionaires.getSelectedValue()
								+ ".xls");
						try {
							outputFile.createNewFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						System.out.println("Output File:"
								+ outputFile.getPath());
						InputStream input = null;
						FileOutputStream output = null;
						try {
							input = new FileInputStream(sourceFile);
							output = new FileOutputStream(outputFile);
							byte[] buffer = new byte[1024];
							int byteRead;
							while ((byteRead = input.read(buffer)) > 0) {
								output.write(buffer, 0, byteRead);
							}
							input.close();
							output.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						System.out.println("No Selection ");
					}
				}

			}
		});
		mi_Export.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				if (!list_Questionaires.isSelectionEmpty()) {
					JFileChooser chooser = new JFileChooser();
					chooser.setCurrentDirectory(new File("."));
					chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					chooser.showOpenDialog(null);
					File selectedPfile = chooser.getSelectedFile();
					try {

						String myPath = selectedPfile.getAbsolutePath();
						new ExportFiles(path + "/"
								+ list_Questionaires.getSelectedValue(),
								myPath, list_Questionaires.getSelectedValue()
										.toString()).start();
					} catch (NullPointerException e) {

					}
				} else {
					JOptionPane
							.showMessageDialog(
									null,
									"Select the questionaire you would like to import!",
									"Select Questionaire",
									JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		mi_Import.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new File("."));
				chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				chooser.showOpenDialog(null);
				File selectedPfile = chooser.getSelectedFile();
				try {

					String myPath = selectedPfile.getAbsolutePath();
					new ImportFile(selectedPfile.getAbsolutePath().toString(),
							path, list_Questionaires, model).start();
				} catch (NullPointerException e) {

				}

			}
		});

		this.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {

			}

			@Override
			public void windowIconified(WindowEvent e) {

			}

			@Override
			public void windowDeiconified(WindowEvent e) {

			}

			@Override
			public void windowDeactivated(WindowEvent e) {

			}

			@Override
			public void windowClosing(WindowEvent e) {
				saveToJSON();
				try {
					questionaireSocketRunnable.close();
					TableRecord.sqlConnection.close();
				} catch (IOException e1) {
					// What happens if the service manager cannot be closed
					System.out.println("Close Socket Server");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(0);
			}

			@Override
			public void windowClosed(WindowEvent e) {
			}

			@Override
			public void windowActivated(WindowEvent e) {

			}
		});
		mi_UserServices.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent event) {
				new UserServices(login_Path);

			}
		});

		pack();
	}

	private void saveToJSON() {
		try {
			JSONArray array = new JSONArray();
			JSONObject object = null;
			String[] values = null;
			for (int i = 0; i < model.size(); i++) {
				values = model.getElementAt(i).toString().split("-");
				object = new JSONObject();
				object.put("Type", values[0]);
				object.put("Stage", values[1]);

				array.put(object);
				values = null;
				object = null;
			}
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
					json_File_path)));
			System.out.println(array.toString());
			writer.write(array.toString());
			writer.close();

		} catch (JSONException e) {

		} catch (IOException e) {

		}

	}

	private void gui() {
		// Ramiz Code
		JPanel mainPanel = new JPanel(new BorderLayout());
		JPanel cPanel = new JPanel();
		cPanel.setLayout(new GridLayout(1, 2));
		JPanel leftPanel = new JPanel(new GridLayout(3, 1));
		b_Add = new JButton("Add Questionaire");
		b_Remove = new JButton("Remove Questionaire");
		b_Mod = new JButton("Modify Questionaire");
		JPanel panelOne = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelOne.add(b_Add);
		leftPanel.add(panelOne);
		JPanel panelTwo = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTwo.add(b_Remove);
		leftPanel.add(panelTwo);
		JPanel panelThree = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelThree.add(b_Mod);
		leftPanel.add(panelThree);
		cPanel.add(leftPanel);
		model = new DefaultListModel();
		list_Questionaires = new JList(model);
		cPanel.add(new JScrollPane(list_Questionaires));
		mainPanel.add(cPanel, BorderLayout.CENTER);
		// Save Button

		add(mainPanel);
		// Content of the dialog box Amir's Code
		b_Create = new JButton("Create");
		textField_Type = new JTextField();
		textField_Stage = new JTextField();

		setLocationRelativeTo(null);

		setVisible(true);
	}

	public void menuBar() {
		// Ramiz Code
		JMenuBar menuBar = new JMenuBar();
		m_File = new JMenu("File");
		m_About = new JMenu("About");
		m_Help = new JMenu("Help");
		mi_Import = new JMenuItem("Import");
		mi_Export = new JMenuItem("Export");
		mi_ExportRecord = new JMenuItem("Export Record");
		mi_Help = new JMenuItem("Help");
		mi_About = new JMenuItem("About");
		mi_UserServices = new JMenuItem("User Services");
		m_File.add(mi_Import);
		m_File.add(mi_Export);
		m_File.add(mi_ExportRecord);
		m_Help.add(mi_Help);
		m_Help.add(mi_UserServices);
		m_About.add(mi_About);

		setJMenuBar(menuBar);
		menuBar.add(m_File);
		menuBar.add(m_About);
		menuBar.add(m_Help);

	}

	/**
	 * Checks through a specific file and updates the questionaireslist
	 * 
	 * @param file
	 */
	private void updateQuestionairesList(File file) {
		model.removeAllElements();
		for (File entry : file.listFiles()) {
			if (entry.getName().endsWith(".json")) {
				// System.out.println(entry.getName());
				String name = entry.getName().substring(0,
						entry.getName().length() - 5);
				// System.out.println(name);
				model.addElement(name);
			}
		}
		sortList(model);
		list_Questionaires.setModel(model);

	}

	/**
	 * This method sorts the list in alphabetical order
	 * 
	 * @param myModel
	 *            the defaultmismodel of the jlsit list_questionaire
	 */
	public void sortList(DefaultListModel myModel) {
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < model.size(); i++) {
			list.add((String) model.getElementAt(i));
		}
		Collections.sort(list);
		model.removeAllElements();
		for (int i = 0; i < list.size(); i++) {
			model.addElement(list.get(i));
		}
		list.removeAll(list);
	}

}
