import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter.DEFAULT;

public class ImportFile extends Thread {
	private String fileToImport, pathToCopy;
	private String name = null;
	private File source_JSON, source_XLS;
	private JList list;
	private DefaultListModel model;

	public ImportFile(String pathToCopy, String fileToImport, JList list,
			DefaultListModel model) {
		this.fileToImport = fileToImport;
		this.pathToCopy = pathToCopy;
		this.model = model;
		this.list = list;
		System.out.println("FIle to IMPORT:   " + fileToImport);
		System.out.println("PATHTOCOPY: " + pathToCopy);
		File file = new File(pathToCopy);
		name = file.getName();
	}

	public void run() {
		if (checkOne()) {
			if (checkTwo()) {
				File file = new File(fileToImport + "/" + name + ".json");
				File fileTwo = new File(fileToImport + "/" + name + ".xls");
				System.out.println("FILE ONE: " + file.getAbsolutePath());
				System.out.println("FILE TWO: " + fileTwo.getAbsolutePath());
				try {
					if (!file.exists()) {

						file.createNewFile();
						System.out.println("FILE ONE CREATED!");
					}
					if (!fileTwo.exists()) {
						fileTwo.createNewFile();
						System.out.println("FILE TWO CREATED!");
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				initialize();
				try {
					copyFile(source_JSON, file);
					copyFile(source_XLS, fileTwo);
					updateQuestionairesList(new File(fileToImport));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {
				JOptionPane.showMessageDialog(null,
						"Wrong File format choose a different directory",
						"Wrong Format", JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			JOptionPane.showMessageDialog(null,
					"Wrong File format choose a different directory",
					"Wrong Format", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/**
	 * From: http://www.journaldev.com/861/4-ways-to-copy-file-in-java
	 * 
	 * @param source
	 * @param dest
	 * @throws IOException
	 */
	private void copyFile(File source, File dest) throws IOException {
		FileChannel sourceChannel = null;
		FileChannel destChannel = null;
		try {
			sourceChannel = new FileInputStream(source).getChannel();
			destChannel = new FileOutputStream(dest).getChannel();
			destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
		} finally {
			sourceChannel.close();
			destChannel.close();
		}
		System.out.println("COPIED");
	}

	/**
	 * 
	 * @return
	 */
	public boolean checkOne() {
		File[] children = new File(pathToCopy).listFiles();
		int f = 0;
		for (File s : children) {
			if (s.getName().endsWith("json") || s.getName().endsWith("xls")) {
				f++;
			}
		}
		System.out.println(f);
		if (f == 2) {
			return true;
		} else {
			return false;
		}
	}

	public boolean checkTwo() {
		String[] pathss = fileToImport.split("/");
		File file = new File(fileToImport);
		String name = pathss[pathss.length - 1];
		if (name.equals(file.getName().toString())) {
			return true;
		} else {
			return false;
		}
	}

	private void initialize() {
		source_JSON = new File(fileToImport + "/" + name + ".json");
		source_XLS = new File(fileToImport + "/" + name + ".xls");

	}

	/**
	 * Checks through a specific file and updates the questionaireslist
	 * 
	 * @param file
	 */
	private void updateQuestionairesList(File file) {
		model.removeAllElements();
		for (File entry : file.listFiles()) {
			if (entry.getName().endsWith(".json")) {
				// System.out.println(entry.getName());
				String name = entry.getName().substring(0,
						entry.getName().length() - 5);
				// System.out.println(name);
				model.addElement(name);
			}
		}
		sortList(model);
		list.setModel(model);

	}

	/**
	 * This method sorts the list in alphabetical order
	 * 
	 * @param myModel
	 *            the defaultmismodel of the jlsit list_questionaire
	 */
	public void sortList(DefaultListModel myModel) {
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < model.size(); i++) {
			list.add((String) model.getElementAt(i));
		}
		Collections.sort(list);
		model.removeAllElements();
		for (int i = 0; i < list.size(); i++) {
			model.addElement(list.get(i));
		}
		list.removeAll(list);
	}

}
