package networkdiscovery;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class DatagramNetworkDiscovery {
	protected DatagramSocket registerSocket;
	protected InetAddress host;
	protected int port;
	protected int servicePort;
	protected int receivedPacketSize = 15000;
	protected String serviceIDString;
	
	public DatagramNetworkDiscovery(int port, int servicePort, String serviceIDString) throws IOException
	{
		this.host = InetAddress.getLocalHost();
		this.port = port;
		this.servicePort = servicePort;
		this.serviceIDString = serviceIDString;
		registerSocket = new DatagramSocket(port, host);
		registerSocket.setBroadcast(true);
		System.out.println("Network Discovery Started...");
	}
	
	public void listenPacket() throws IOException {
		while(true) 
		{
			System.out.println("Receiving Packet...");
			byte[] receiveBufferByte = new byte[receivedPacketSize];
			DatagramPacket receivedPacket = new DatagramPacket(receiveBufferByte, receiveBufferByte.length);
			registerSocket.receive(receivedPacket);
			System.out.println("Received Packet from: " + receivedPacket.getAddress().toString());
			if(receivedPacket != null)
			{
				new SendServiceInfoThread(receivedPacket).start();
			}
		}
	}
	
	private class SendServiceInfoThread extends Thread{
		private DatagramPacket receivedPacket;
		public SendServiceInfoThread(DatagramPacket receivedPacket) throws IOException
		{	
			this.receivedPacket = receivedPacket;
		}
		
		public void run()
		{
			InetAddress clientHostAddress = receivedPacket.getAddress();
			int clientPort = receivedPacket.getPort();
			if(clientHostAddress != null)
			{
				String clientMessage = new String(receivedPacket.getData()).trim();
				if(clientMessage.contains(serviceIDString));
				{
					try 
					{
						String serverMessage = InetAddress.getLocalHost().getHostAddress() + ", " + servicePort;
						byte[] sendByte = serverMessage.getBytes();
						//Send the service information 
						DatagramPacket serviceInfoPacket = new DatagramPacket(sendByte, sendByte.length, clientHostAddress, clientPort);
						registerSocket.send(serviceInfoPacket);		
						System.out.println("Send Packet to : " + clientHostAddress.toString());
					} 
					catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public void close()
	{
		if(!registerSocket.isClosed())
		{
			try {
				registerSocket.setBroadcast(false);
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			registerSocket.close();
			System.out.println("Network Discovery Stopped");
		}
	}
}
