DROP TABLE IF EXISTS 'Patient';
DROP TABLE IF EXISTS 'Questionaire';

CREATE TABLE `Patient` (
  `id` INTEGER PRIMARY KEY	AUTOINCREMENT ,
  `name` VARCHAR(50) NOT NULL,
  `dateOfBirth` DATE NOT NULL ,
  'gender' VARCHAR(6) NOT NULL,
  'nationality' VARCHAR(50) NULL,
  `illness` VARCHAR(100) NOT NULL ,
  `stage` VARCHAR(45) NOT NULL , 
   UNIQUE('name','dateOfBirth', 'illness'));
   
CREATE  TABLE `Questionaire` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT,
  `title` VARCHAR(200) NOT NULL UNIQUE,
  `illness` VARCHAR(100) NOT NULL ,
  `stage` VARCHAR(45) NOT NULL);