INSERT INTO patient(name, dateOfBirth, illness, stage)
VALUES('Long Le', '05-01-1994', 'Cancer', '1');
INSERT INTO patient(name, dateOfBirth, illness, stage)
VALUES('Trung Le', '11-12-1994', 'Cancer', '2');