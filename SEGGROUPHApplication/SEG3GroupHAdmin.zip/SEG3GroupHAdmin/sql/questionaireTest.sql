INSERT INTO questionaire (title, illness, stage, filepath)
VALUES('json', 'Otaku', '5', 'questions/json.json');