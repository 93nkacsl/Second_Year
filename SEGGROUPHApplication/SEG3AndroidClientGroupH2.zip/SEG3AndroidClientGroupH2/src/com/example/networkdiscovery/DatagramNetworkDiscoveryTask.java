package com.example.networkdiscovery;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.MulticastLock;
import android.os.AsyncTask;

public class DatagramNetworkDiscoveryTask extends AsyncTask<Void, Void, String[]>{

	protected Context context;
	protected MulticastLock mDSNLock;
	protected DatagramSocket discoverSocket;
	protected DatagramPacket receivedPacket;
	protected int receivedPacketSize = 15000;
	protected String serviceIDString;
	protected InetAddress UDPAddress;
	protected int UDPPort;
	protected boolean hasFoundServer;
	
	/**
	 * This method automatically finds the server specified in the network
	 * @param serviceName the name of the service
	 * @throws SocketException 
	 */
	public DatagramNetworkDiscoveryTask(Context context, InetAddress UDPAddress, int UDPPort, String serviceIDString) throws SocketException {
		super();
		this.context = context;
		this.UDPAddress = UDPAddress;
		this.UDPPort = UDPPort;
		this.serviceIDString = serviceIDString;
	}
	
	/**
	 * This method opens wifi mDSN lock.
	 */
	public void openMDSNLlock()
	{
		WifiManager wifi = (WifiManager) context.getSystemService( Context.WIFI_SERVICE );
		mDSNLock = wifi.createMulticastLock("Network Discovery mDSN Lock");
		mDSNLock.setReferenceCounted(true);
		mDSNLock.acquire();
	}
	 
	@Override
	protected String[] doInBackground(Void... params) {
		String[] serviceInfo = null;
		try 
		{
			openMDSNLlock();
			discoverSocket = new DatagramSocket();
			discoverSocket.setBroadcast(true);
			discoverSocket.setSoTimeout(10000);
			//Send message that identifies the service being used. If the serviceIDString is correct, the server will reply back
			String clientMessage = serviceIDString;
			byte[] sendByte = clientMessage.getBytes();
			DatagramPacket datagramPacket = new DatagramPacket(sendByte, sendByte.length, UDPAddress, UDPPort);
			discoverSocket.send(datagramPacket);
			System.out.println("datagramPacket SENT");
			byte[] receivedByte = new byte[receivedPacketSize];
			receivedPacket = new DatagramPacket(receivedByte, receivedByte.length);
			discoverSocket.receive(receivedPacket);
			hasFoundServer = true;
			//Receive message from the server, it will contain the ip address and the port number
			String serverMessage = new String(receivedPacket.getData()).trim();
			serviceInfo = serverMessage.split(", ");
			System.out.println("Server Information RECEIVED: " + serverMessage);
		} 
		catch (SocketException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
		return serviceInfo;
	}	
	
	@Override
	protected void onPostExecute(String[] result) {
		try {
			super.onPostExecute(result);
			mDSNLock.release();
			discoverSocket.setBroadcast(false);
			discoverSocket.close();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
