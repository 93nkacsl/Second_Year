package com.example.socket;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutionException;

import android.os.AsyncTask;

public class SocketManager {
	public static String getIPAddress(String hostName)
	{
		String ipAddress = null;
		String[] params = {hostName};
		FindIPFromHostTask findIPFromHostTask = new SocketManager.FindIPFromHostTask();
		try {
			ipAddress = findIPFromHostTask.execute(params).get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ipAddress;
	}
	
	private static class FindIPFromHostTask extends AsyncTask<String, Void, String>
	{

		@Override
		protected String doInBackground(String... params) {
			String ipAddress = findIPfromHost(params[0]);
			return ipAddress;
		}
		
		private String findIPfromHost(String hostname)
		{
			String IPAddress = null;
			try 
			{
				InetAddress[] searchedInetAddress = InetAddress.getAllByName(hostname);
				for(int i = 0; i<searchedInetAddress.length; i++)
				{
					 IPAddress = searchedInetAddress[i].getHostAddress();
				}
			} 
			catch (UnknownHostException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return IPAddress;
		}
	}
}	
