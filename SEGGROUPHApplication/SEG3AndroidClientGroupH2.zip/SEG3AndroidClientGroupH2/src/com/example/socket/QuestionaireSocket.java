package com.example.socket;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QuestionaireSocket extends ClientSocket {

	public QuestionaireSocket(String host, int port) throws IOException {
		super(host, port);
	}
	
	
	public QuestionaireSocket(String host, int port, File dirForReceivingFiles, File dirForSendingFiles) throws IOException{
		super(host, port, dirForReceivingFiles, dirForSendingFiles);
	}
	
	/**
	 * This method sends the patient's information to the server
	 * @param patientDetailArrayList an ArrayList containing patient details. The first index should be the patient's name, then date of birth, then illness
	 * @throws IOException 
	 * @throws FailureException 
	 */
	public File retrieveQuestionaire(ArrayList<String> patientDetailArrayList) throws IOException, FailureException
	{
		String patientDetail = patientDetailArrayList.get(0);
		for(int i = 1; i<patientDetailArrayList.size(); i++)
		{
			patientDetail = patientDetail + ", " + patientDetailArrayList.get(i); 
		}
		sendRequest("#PATIENT: " + patientDetail);
		File questionaireFile = (File) processRequest(retrieveRequest());
		return questionaireFile;
	}
	/**
	 * This method retrieve the illness and stage list from the admin app
	 * @return the HashMap representation of the illness and the stages
	 * @throws IOException
	 * @throws FailureException 
	 */
	public HashMap<String,String[]> retrieveIllnessInfo() throws IOException, FailureException
	{
		HashMap<String, String[]> illnessInfoHashMap = null;
		sendRequest("#REQUEST-ILLNESS-INFO;");
		String returnedRequest = retrieveRequest();
		illnessInfoHashMap = (HashMap<String,String[]>) processRequest(returnedRequest);
		return illnessInfoHashMap;
	}
	
	/**
	 * This method retrieve the illness and stage list from the admin app
	 * @return the HashMap representation of the illness and the stages
	 * @throws IOException
	 * @throws FailureException 
	 */
	public HashMap<String,String[]> retrievePatientIllness(String patientName, String dateOfBirth) throws IOException, FailureException
	{
		HashMap<String, String[]> patientIllnessHashMap = null;
		sendRequest("#REQUEST-PATIENT-ILLNESS: " + patientName + ", " + dateOfBirth);
		String returnedRequest = retrieveRequest();
		patientIllnessHashMap = (HashMap<String,String[]>) processRequest(returnedRequest);
		return patientIllnessHashMap;
	}
	
	//TODO Sending answer (in json or array) ...
	/**
	 * This method sends the answer to the server
	 * @throws IOException 
	 */
	public void sendAnswer(String answer, String questionaire) throws IOException
	{
		if(answer!=null) {
			sendRequest("#ANSWER: " + questionaire + "," + answer);
		}
	} 

	@Override
	public Object customCommands(String commandKeyword, String commandObjName) {
		if(commandKeyword.equals("SEND-ILLNESS-INFO"))
		{
			String illnessHashMapString = commandObjName;
			return (HashMap<String,String[]>) convertIllnessInfo(illnessHashMapString);
		}
		else if(commandKeyword.equals("SEND-PATIENT-ILLNESS"))
		{
			String illnessHashMapString = commandObjName;
			return (HashMap<String,String[]>) convertIllnessInfo(illnessHashMapString);
		}
		return null;
	}
	
	/**
	 * This method converts the answer string into a hashmap
	 * @param illnessInfoHashMapString the string representing the answer hash map sent from the android
	 * @return a hashmap containing all of the answers in the answer string
	 */
	protected HashMap<String, String[]> convertIllnessInfo(String illnessInfoHashMapString)
	{
		Pattern illnessInfoPattern = Pattern.compile("([\\w\\-\\s]+=)((\\[([\\w\\s\\-\\/\\,])+\\])|([\\w\\/\\-\\s])+)");
		Matcher matcher = illnessInfoPattern.matcher(illnessInfoHashMapString);
		HashMap<String,String[]> illnessInfoHashMap = new HashMap<String,String[]>();
		while(matcher.find())
		{
			String illnessInfoString = matcher.group();
			int equalSignIndex = illnessInfoString.indexOf("=");
			String illness = illnessInfoString.substring(0, equalSignIndex ).trim();
			String stageString = illnessInfoString.substring(equalSignIndex + 1).trim();
			//Just take off the [ ] of the bracket
			if(stageString.startsWith("["))
			{
				stageString = stageString.substring(1, stageString.length()-1);
			}
			String[] stageArray = stageString.split(", ");
			illnessInfoHashMap.put(illness, stageArray);
		}
		return illnessInfoHashMap;
	}
}
