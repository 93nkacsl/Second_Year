package com.example.socket;

import java.io.IOException;
import java.util.HashMap;

import com.example.socket.ClientSocket.FailureException;

import android.os.AsyncTask;

public abstract class RetrieveIllnessInfoTask extends AsyncTask<Void, Void, HashMap<String, String[]>> {
	
	private String host;
	private int port;
	private QuestionaireSocket questionaireSocket;
	
	/**
	 * This method creates a thread for receiving questionaire files
	 * @param host hostname or IP address of server computer
	 * @param port port the port number for the socket
	 */
	public RetrieveIllnessInfoTask(String host, int port)
	{
		super();
		this.host = host;
		this.port = port;
	}
	/**
	 * This method 
	 * @param params the details of the patient that will be used to retrieve a questionnaire (e.g name, date of birth, illness, stage of illness)
	 * @return
	 */
	protected HashMap<String,String[]> doInBackground(Void... params) {		
		try 
		{
			questionaireSocket = new QuestionaireSocket(host, port);
			System.out.println("Connected to server");
			//Only need one PatientDetailArrayLists
			return questionaireSocket.retrieveIllnessInfo();
		} 
		catch (IOException e) 
		{
			System.out.println("NOT connected to Server");
			e.printStackTrace();
			return null;
		} catch (FailureException e) {
			System.out.println("Cannot retrieve the illness information");
			e.printStackTrace();
			return null;
		}
	}
	@Override
	protected void onPostExecute(HashMap<String,String[]> result) {
		super.onPostExecute(result);
		if(questionaireSocket!=null)
		{
			questionaireSocket.closeStreamAndSocket();
		}
	}
	/**
	 * This method test the connection to the server by sending a message to the server
	 * @return true if there is connection, false if there is no connection
	 */
	public boolean testConnection()
	{
		return questionaireSocket.isConnected();
	}
}
