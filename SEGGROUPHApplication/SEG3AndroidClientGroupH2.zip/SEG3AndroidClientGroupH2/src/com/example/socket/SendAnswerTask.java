package com.example.socket;

import java.io.File;
import java.io.IOException;

import com.example.socket.ClientSocket.FailureException;

import android.os.AsyncTask;

public class SendAnswerTask extends AsyncTask<File, Void, Void> 
{
	private String host;
	private int port;
	private String answerDirPath;
	private QuestionaireSocket questionaireSocket;
	/**
	 * Create a thread to create a socket and send the answer to the server socket
	 * @param host hostname or IP address of server computer
	 * @param port the port number for the socket 
	 * @param answerDirPath the directory path in the server where the answer file is stored
	 */
	public SendAnswerTask(String host, int port, String answerDirPath)
	{
		
		super();
		this.host = host;
		this.port = port;
		this.answerDirPath = answerDirPath;
	}
	
	@Override
	protected Void doInBackground(File... params) {
		try {
			questionaireSocket
			= new QuestionaireSocket(host, port);
			//Although this allows you to send multiple answers, you should only send 1 answer to the server
			for(int i=0; i<params.length; i++)
			{
				questionaireSocket.sendFile(params[i], answerDirPath);
				String request = questionaireSocket.retrieveRequest();
				questionaireSocket.processRequest(request);
			}
			//Close the socket because we don't need to use the socket for anything else anymore
			questionaireSocket.closeStreamAndSocket();
			//Delete the answer files in the internal storage after the files are sent.
			for(int i=0; i<params.length; i++)
			{
				params[i].delete();
			}
		} 
		catch (IOException e) {
			//TODO not connected to host
			e.printStackTrace();
		} catch (FailureException e) {
			//TODO need more detail
			System.out.println("Cannot send answer to the server");
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		questionaireSocket.closeStreamAndSocket();
	}
}
