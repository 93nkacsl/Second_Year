package com.example.socket;

import java.io.IOException;

import com.example.socket.ClientSocket.FailureException;

import android.os.AsyncTask;

public class SendHashMapAnswerTask extends AsyncTask<String, Void, Boolean> 
{
	private String host;
	private int port;
	private QuestionaireSocket questionaireSocket;
	/**
	 * Create a thread to create a socket and send the answer to the server socket
	 * @param host hostname or IP address of server computer
	 * @param port the port number for the socket 
	 * @param answerDirPath the directory path in the server where the answer file is stored
	 */
	public SendHashMapAnswerTask(String host, int port)
	{
		super();
		this.host = host;
		this.port = port;
	}
	
	@Override
	protected Boolean doInBackground(String... params) {
		boolean hasSentAnswer=false;
		try {
			questionaireSocket = new QuestionaireSocket(host, port);
			//Although this allows you to send multiple answers, you should only send 1 answer to the server

			questionaireSocket.sendAnswer(params[0], params[1]);
			String request = questionaireSocket.retrieveRequest();
			hasSentAnswer = (Boolean) questionaireSocket.processRequest(request);
			//Close the socket because we don't need to use the socket for anything else anymore
			questionaireSocket.closeStreamAndSocket();
		} 
		catch (IOException e) {
			e.printStackTrace();
		} catch (FailureException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hasSentAnswer;
	}
}
