package com.example.socket;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import com.example.socket.ClientSocket.FailureException;

import android.os.AsyncTask;

public abstract class RetrieveQuestionaireTask extends AsyncTask<ArrayList<String>, File, File> {
	
	private String host;
	private int port;
	private File dirForReceivingFiles;
	private QuestionaireSocket questionaireSocket;
	
	/**
	 * This method creates a thread for receiving questionaire files
	 * @param host hostname or IP address of server computer
	 * @param port port the port number for the socket
	 * @param dirForReceivingFiles directory where questionaire files will be stored
	 */
	public RetrieveQuestionaireTask(String host, int port, File dirForReceivingFiles)
	{
		super();
		this.host = host;
		this.port = port;
		this.dirForReceivingFiles = dirForReceivingFiles;
	}
	/**
	 * This method 
	 * @param params the details of the patient that will be used to retrieve a questionnaire (e.g name, date of birth, illness, stage of illness)
	 * @return
	 */
	protected File doInBackground(ArrayList<String>... params) {
		File questionaireFile = null;	
		try 
		{
			questionaireSocket = new QuestionaireSocket(host, port);
			System.out.println("Connected to server");
			questionaireSocket.setDirForReceivingFiles(dirForReceivingFiles);
			//Only need one PatientDetailArrayList
			ArrayList<String> patientDetailArrayList = params[0];
			questionaireFile = questionaireSocket.retrieveQuestionaire(patientDetailArrayList);
		} 
		catch (IOException e) 
		{
			//TODO Need dialog 
			System.out.println("Not Connected to Server");
			e.printStackTrace();
			return null;
		} catch (FailureException e) {
			//TODO Need dialog
			System.out.println("Cannot retrieve questionaire from the server");
			return null;
		}
		return questionaireFile;
	}
	@Override
	protected void onPostExecute(File result) {
		super.onPostExecute(result);
		questionaireSocket.closeStreamAndSocket();
	}
	/**
	 * This method test the connection to the server by sending a message to the server
	 * @return true if there is connection, false if there is no connection
	 */
	public boolean testConnection()
	{
		return questionaireSocket.isConnected();
	}
}