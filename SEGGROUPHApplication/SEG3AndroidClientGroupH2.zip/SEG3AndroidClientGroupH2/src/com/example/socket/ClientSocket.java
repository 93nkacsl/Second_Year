package com.example.socket;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class ClientSocket extends Socket
{
	protected DataInputStream dataIS;
	protected DataOutputStream dataOS;
	protected File dirForReceivingFiles;
	protected File dirForSendingFiles;
	protected String lastRequestSent;
	protected String lastRequestReceived;
	protected String state; 
	protected String host;
	protected int port;
	
	/**
	 * This method create a new ClientSocket instance.
	 * @param host IP address or host name of the server
	 * @param port the port number that the socket will use to connect to the server
	 * @throws IOException
	 */
	public ClientSocket(String host, int port) throws IOException {
		super(host, port);
		this.host = host;
		this.port = port;
		dataIS = new DataInputStream(this.getInputStream());
		dataOS = new DataOutputStream(this.getOutputStream());
	}
	/**
	 * This method creates a new ClientSocket instance.
	 * @param host IP address or host name of the server
	 * @param port the port number that the socket will use to connect to the server
	 * @param dirForSendingFiles the directory where all of the files that needs to be sent are
	 * @param dirForReceivingFiles the directory where all of the files that needs to be received are
	 * @throws IOException
	 */
	public ClientSocket(String host, int port, File dirForSendingFiles, File dirForReceivingFiles) throws IOException
	{
		this(host, port);
		//Make directories if they are not null and don't exist yet
		if(dirForSendingFiles!=null)
		{
			this.dirForReceivingFiles = dirForReceivingFiles;
			if(!dirForReceivingFiles.exists())
			{
				dirForReceivingFiles.mkdirs();
			}
		}

		if(dirForSendingFiles!=null)
		{
			this.dirForSendingFiles = dirForSendingFiles;
			if(!dirForSendingFiles.exists())
			{
				dirForSendingFiles.mkdirs();
			}
		}
	}

	/**
	 * This method returns the server socket request.
	 * @return String request
	 * @throws IOException 
	 */
	public String retrieveRequest() throws IOException
	{
		String request = "";
		System.out.println("Retrieving request ...");
		request = dataIS.readUTF();
		System.out.println("Retrieve request COMPLETE");
		lastRequestReceived = request;
		return request;
	}
	
	/**
	 * This method sends a request to the server socket.
	 * @throws IOException 
	 */
	public void sendRequest(String request) throws IOException
	{	
		dataOS.writeUTF(request);
		dataOS.flush();
		lastRequestSent = request;
	}
	
	/**
	 * This method processes the server socket request automatically. 
	 * @param request the request string to be processed
	 * @return any object that can be returned from processing the request
	 * @throws IOException 
	 * @throws FailureException exception when data sent to the server cannnot be processed
	 */
	public Object processRequest(String request) throws IOException, FailureException 
	{
		System.out.println("Processing request ...");
		if (request.startsWith("#"))
		{
			String command = "";
			String commandKeyword = "";
			String commandObjName  = "";
			//Commands will have pattern beginning with # and ending with : followed by an object
			Pattern commandPattern = Pattern.compile("^(#[A-Z]{1}([_-]?[A-Z]+)+[:;])");
			Matcher commandMatcher = commandPattern.matcher(request);
			if(commandMatcher.find())
			{
				command = commandMatcher.group(1);
				commandKeyword = command.substring(1, command.length()-1);
				//If there is a : at the end of the command then there will be an object or name of object associated with that command as well
				if(command.charAt(command.length()-1) == ':')
				{
					commandObjName = request.substring(command.length()).trim();
				}
				//Process the request depending on the command				
				if(commandKeyword.equals("REQUEST_FILE"))
				{
					sendFile(new File(dirForSendingFiles, commandObjName));
				}
				else if(commandKeyword.equals("SEND_FILE"))
				{
					return receiveFile(dirForReceivingFiles, commandObjName);
				}	
				else if(commandKeyword.equals("SUCCESS"))
				{
					return true;
				}
				else if(commandKeyword.equals("FAILURE"))
				{
					throw new FailureException(commandObjName);
				}
				else
				{
					return customCommands(commandKeyword, commandObjName);
				}
			}
			System.out.println("Processing request: " + command + " SUCCESS");
		}
		else {
			System.out.println("SERVER:" + request);
		}
		return null;
	}
	/**
	 * Tell the server that processing the request was a success
	 * @throws IOException
	 */
	public void sendSuccessNotice() throws IOException
	{
		sendRequest("#SUCCESS;");
	}
	/**
	 * Tell the server that processing the request was a failure
	 * @throws IOException
	 */
	public void sendFailureNotice() throws IOException
	{
		sendRequest("#FAILURE;");
	}
	/**
	 * This method processes custom commands from the admin app that has not been previously sdefined in the processRequest() method
	 */
	public abstract Object customCommands(String commandKeyword, String commandObjName);
	
	/**
	 * This method requests a file from the server
	 * @param fileName the name of the file(include extension like .jsn or .jpg) or file's path on the server to retrieve
	 * @throws IOException 
	 * @throws FailureException 
	 */
	public File requestFile(String fileName) throws IOException, FailureException 
	{
		sendRequest("#REQUEST_FILE:" + fileName);
		String request = retrieveRequest();
		File requestedFile = (File) processRequest(request);
		return requestedFile;
	}
	
	/**
	 * This method sends a file to the server socket. 
	 * The file will be saved in a directory specified in the server side.
	 * @param file the file to be sent
	 * @return the file requested 
	 * @throws IOException 
	 */
	public void sendFile(File file) throws IOException {
		System.out.println("Sending file " + file.getName() + "...");
		sendRequest("#SEND_FILE:" + file.getName());
		sendFileContent(file);
	}
	
	/**
	 * This method sends a file to the server and store it in a specified directory.
	 * The server will create the directories in the directory path if they have not been created yet. 
	 * The directories will be created in a parent directory specified in the server side.
	 * e.g dirPathInServer is childDir1/childDir2 and the designated folder is parentDir then the childDir1 and childDir2 will be created, 
	 * and a file called file1 will have the file path of parentDir/childDir1/childDir2/file1
	 * @param file the file to be sent
	 * @param dirPathInServer the directory path to store the file in the server
	 * @throws IOException 
	 */
	public void sendFile(File file, String dirPathInServer) throws IOException
	{
		System.out.println("Sending file " + file.getName() + "...");
		sendRequest("#SEND_FILE:" + dirPathInServer + "/" + file.getName());
		sendFileContent(file);
	}
	/**
	 * This method reads the file and sends each line to the server socket
	 * @param File file the file, whose content will be sent to the server
	 * @throws IOException 
	 */
	protected void sendFileContent(File file) throws IOException
	{
		try
		{
			BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
			String fileLine = null;
			while((fileLine = bufferedReader.readLine())!=null) 
			{
				dataOS.writeUTF(fileLine);
			}
			//Tell server that the file has been sent
			sendRequest("#COMPLETE;");
			bufferedReader.close();
			dataOS.flush();
			System.out.println("Sending file " + file.getName() + "COMPLETE");
		} 
		catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	/**
	 * This method receives a file from the server
	 * @param String dirForSave the directory in which the file retrieved will be saved
	 * @param String fileName the name of the file(include extension) which will be saved
	 */
	public File receiveFile(File dirForReceivingFiles, String fileName)
	{
		System.out.println("Receiving file: " + fileName + "...");
		//Handle the case where the fileName is actually a file path
		if(fileName.contains(";"))
		{
			//the directory path will be everything before the file name in a file path
			int dirSeparatorIndex = fileName.lastIndexOf("/");
			String requestedDirPath = fileName.substring(0, dirSeparatorIndex);
			fileName = fileName.substring(dirSeparatorIndex + 1);
			String dirPath = dirForReceivingFiles.getName() + "/" + requestedDirPath;
			dirForReceivingFiles =  new File(dirPath);
		}
		File file = new File(dirForReceivingFiles, fileName);
		try 
		{
			//Create file if it has not been previously created
			if(!file.exists())
			{
				file.createNewFile();
			}
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));
			
			//Read the data of the file sent by the client
			String fileString = null;
	        while((fileString = dataIS.readUTF())!=null && !fileString.equals("#COMPLETE;"))
	        {
	        	bufferedWriter.write(fileString + "\n");
	        }
	        bufferedWriter.flush();
	        bufferedWriter.close();
	        
	        //Tell the server that the file has been received successfully
	        sendSuccessNotice();
	        System.out.println("Receiving file: " + fileName + " SUCCESS");
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return file;
	}
	
	/**
	 * This method safely closes the current socket 
	 * It sends a message to tell the server to close the socket.
	 * Then the socket will close its the input and output streams before closing.
	 */
	public void closeStreamAndSocket()
	{
		try 
		{
			//Tell the server to close the socket as well
			dataIS.close();
			dataOS.close();
			super.close();
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This method returns the directory where files received by this socket will be saved
	 * @return
	 */
	public File getDirForReceivingFiles() {
		return dirForReceivingFiles;
	}
	/**
	 * This method sets the directory where files received by the this socket will be saved.
	 * It will also create the folders if they don't exist.
	 * @param dirForReceivingFiles
	 */
	public void setDirForReceivingFiles(File dirForReceivingFiles) {
		this.dirForReceivingFiles = dirForReceivingFiles;
		if(!dirForReceivingFiles.exists())
		{
			dirForReceivingFiles.mkdirs();
		}
	}
	/**
	 * This method returns the directory which holds files that are going to be sent to the server socket
	 * @param dirForReceivingFiles
	 */
	public File getDirForSendingFiles() {
		return dirForSendingFiles;
	}
	/**
	 * This method sets the directory which holds files that are going to be sent to the server socket.
	 * It will also create the folders if they don't exist.
	 * @param dirForSendingFiles
	 */
	public void setDirForSendingFiles(File dirForSendingFiles) {
		this.dirForSendingFiles = dirForSendingFiles;
		if(!dirForSendingFiles.exists())
		{
			dirForSendingFiles.mkdirs();
		}
	}
	protected class FailureException extends Exception {
		public FailureException(String message)
		{
			super(message);
		}
	}
}
