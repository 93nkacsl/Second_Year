package com.example.socket;

import java.io.IOException;
import java.util.HashMap;

import com.example.socket.ClientSocket.FailureException;

import android.os.AsyncTask;

public class RetrievePatientIllness extends AsyncTask<String, Void, HashMap<String,String[]>>{
	private String host;
	private int port;
	private QuestionaireSocket questionaireSocket;
	
	/**
	 * This method creates a thread for receiving questionaire files
	 * @param host hostname or IP address of server computer
	 * @param port port the port number for the socket
	 */
	public RetrievePatientIllness(String host, int port)
	{
		super();
		this.host = host;
		this.port = port;
	}
	/**
	 * This method 
	 * @param params the details of the patient that will be used to retrieve a questionnaire (e.g name, date of birth, illness, stage of illness)
	 * @return
	 */
	protected HashMap<String,String[]> doInBackground(String... params) {		
		HashMap<String,String[]> resultHashMap = null;
		try 
		{
			questionaireSocket = new QuestionaireSocket(host, port);
			System.out.println("Connected to server");
			//Only need one PatientDetailArrayList
			resultHashMap = questionaireSocket.retrievePatientIllness(params[0], params[1]);
			questionaireSocket.sendSuccessNotice();
		} 
		catch (IOException e) 
		{
			System.out.println("NOT Connected to Server");
			e.printStackTrace();
		} 
		catch (FailureException e) {
			System.out.println("The patient has not been registered to the system");
			return null;
		} 
		return resultHashMap;
	}
	@Override
	protected void onPostExecute(HashMap<String,String[]> result) {
		super.onPostExecute(result);
		questionaireSocket.closeStreamAndSocket();
	}
	/**
	 * This method test the connection to the server by sending a message to the server
	 * @return true if there is connection, false if there is no connection
	 */
	public boolean testConnection()
	{
		return questionaireSocket.isConnected();
	}
}
