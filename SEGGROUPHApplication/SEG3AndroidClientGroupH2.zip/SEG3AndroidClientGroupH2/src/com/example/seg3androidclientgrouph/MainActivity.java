package com.example.seg3androidclientgrouph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.example.networkdiscovery.DatagramNetworkDiscoveryTask;
import com.example.socket.RetrieveIllnessInfoTask;
import com.example.socket.RetrievePatientIllness;
import com.example.socket.RetrieveQuestionaireTask;

public class MainActivity extends FragmentActivity {

	private String year, month, day;
	private EditText et_dateOfBirth, et_Fname, et_Lname;
	private Spinner spinner_Title, spinner_Countries, spinner_stage,
			spinner_Type;
	private Button b_startQuestionaire;
	private RadioButton CYBtn, CNBtn;
	private RadioButton maleBtn, femaleBtn;
	int list_size = 0;
	private ArrayList<String> content;
	private String host = "159.92.183.249";
	private String gender;
	private String illness = null;
	private String stage;
	private String nationality;
	private String name;
	private String dateOfBirth;
	private int port = 9998;
	private HashMap<String, String[]> illnessHashMap = null;
	private HashMap<String, String[]> patientIllnessHashMap = null;
	private HashMap<String, String[]> newPatientIllnessHashMap = null;
	private boolean hasBeenToClinic = false;
	private boolean hasDataInDatabase =false;
	private ArrayList<String> illnessList;
	private File questionaireFile;
	private Intent startQuestionIntent;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// START NETWORK DISCOVERY FOR PORT AND HOST
		startNetworkDiscovery();
		setContentView(R.layout.activity_main);
		et_Fname = (EditText) findViewById(R.id.et_FName);
		et_Lname = (EditText) findViewById(R.id.et_LName);
		spinner_Countries = (Spinner) findViewById(R.id.spinner_Nationality);
		spinner_stage = (Spinner) findViewById(R.id.spinner_Stage);
		spinner_Type = (Spinner) findViewById(R.id.spinner_Type);
		et_dateOfBirth = (EditText) findViewById(R.id.et_DatePicker);
		maleBtn = (RadioButton) findViewById(R.id.rb_Male);
		femaleBtn = (RadioButton) findViewById(R.id.rb_Female);
		initialize();
	}

	private void initialize() {
		// Widgets created
		CYBtn = (RadioButton) findViewById(R.id.rb_CYes);
		CNBtn = (RadioButton) findViewById(R.id.rb_CNo);

		CYBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// Populate the list with information on the database.
				if(et_Fname.getText().toString().length() > 0 && et_dateOfBirth.getText().toString().length() > 0 && et_Lname.getText().toString().length() > 0){
				spinner_Countries.setEnabled(false);
				femaleBtn.setEnabled(false);
				maleBtn.setEnabled(false);
				}
	
				String firstName = (et_Fname.getText().toString()).trim();
				String lastName = (et_Lname.getText().toString()).trim();
				String dateOfBirth = et_dateOfBirth.getText().toString().trim();
				hasBeenToClinic = true;
				if (firstName != null && lastName != null
						&& dateOfBirth != null && firstName.length()>0 && lastName.length()>0 && dateOfBirth.length()>0) {
	
					String name = firstName + " " + lastName;
					String[] params = { name, dateOfBirth };
					new MainRetrievePatientIllnessTask(host, port)
							.execute(params);
					spinner_Type.setEnabled(true);
					spinner_stage.setEnabled(true);
				}
				else
				{
					spinner_Type.setEnabled(false);
					spinner_stage.setEnabled(false);
				}
			}
		});
		CNBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(et_Fname.getText().toString().length() > 0 && et_dateOfBirth.getText().toString().length() > 0 && et_Lname.getText().toString().length() > 0){
				spinner_Countries.setEnabled(true);
				femaleBtn.setEnabled(true);
				maleBtn.setEnabled(true);
				spinner_Type.setEnabled(true);
				spinner_stage.setEnabled(true);
				//Add default values:
				spinner_Countries.setSelection(0);
				femaleBtn.performClick();
				}
				if (newPatientIllnessHashMap != null) {
					hasBeenToClinic = false;
					populateIllnessAndStageSpinner(newPatientIllnessHashMap);
				}
			}
		});
		spinner_Countries.setEnabled(false);
		spinner_stage.setEnabled(false);
		spinner_Type.setEnabled(false);
		femaleBtn.setEnabled(false);
		maleBtn.setEnabled(false);
		et_Fname.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			@Override
			public void afterTextChanged(Editable s) {
				notifyFinishPersonalDetail();
			}
		});
		et_Lname.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			@Override
			public void afterTextChanged(Editable s) {
				notifyFinishPersonalDetail();
			}
		});
		et_dateOfBirth.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			@Override
			public void afterTextChanged(Editable s) {
				notifyFinishPersonalDetail();
			}
		});
		

		//maleBtn = (RadioButton) findViewById(R.id.rb_Male);
		//femaleBtn = (RadioButton) findViewById(R.id.rb_Female);
		femaleBtn.performClick();

		maleBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				gender = "Male";
			}
		});

		femaleBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				gender = "Female";
			}
		});

		spinner_Title = (Spinner) findViewById(R.id.spinner_Title);
		String[] list_Titles = getResources().getStringArray(
				R.array.list_Titles);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_dropdown_item, list_Titles);
		spinner_Title.setAdapter(adapter);
		//et_dateOfBirth = (EditText) findViewById(R.id.et_DatePicker);
		et_dateOfBirth.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				DialogFragment datePickerFragment = new DatePickerFragment();
				datePickerFragment.show(getFragmentManager(), "datePicker");
			}
		});

		//spinner_Countries = (Spinner) findViewById(R.id.spinner_Nationality);
		ArrayList<String> countries = getCountries();
		ArrayAdapter<String> adapter_countries = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_dropdown_item, countries);
		spinner_Countries.setAdapter(adapter_countries);
		spinner_Countries
				.setOnItemSelectedListener(new OnItemSelectedListener() {

					@Override
					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int arg2, long arg3) {
						nationality = (String) arg0.getItemAtPosition(arg2);
					}

					@Override
					public void onNothingSelected(AdapterView<?> arg0) {

					}
				});
		//et_Fname = (EditText) findViewById(R.id.et_FName);
		//et_Lname = (EditText) findViewById(R.id.et_LName);
		b_startQuestionaire = (Button) findViewById(R.id.b_StartQuestionaire);
		b_startQuestionaire.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				v.setEnabled(false);
				boolean hasEnoughData = false;
				startQuestionIntent = new Intent(MainActivity.this,
						Questionaire.class);
				String firstName = (et_Fname.getText().toString()).trim();
				String lastName = (et_Lname.getText().toString()).trim();
				dateOfBirth = et_dateOfBirth.getText().toString().trim();
				name = firstName + " " + lastName;

				content = new ArrayList<String>();
				if (hasBeenToClinic) {
					if (firstName.length() > 0 && lastName.length() > 0
							&& dateOfBirth.length() > 0 && illness!=null && stage!=null) {
						startQuestionIntent.putExtra("first name", firstName);
						startQuestionIntent.putExtra("last name", lastName);
						content.add(name);
						content.add(dateOfBirth);
						content.add(illness);
						content.add(stage);
						hasEnoughData = true;
					}
				} else {
					if (firstName.length() > 0 && lastName.length() > 0
							&& dateOfBirth.length() > 0 && nationality != null
							&& gender != null && illness!=null && stage!=null) {
						startQuestionIntent.putExtra("first name", firstName);
						startQuestionIntent.putExtra("last name", lastName);
						content.add(name);
						content.add(dateOfBirth);
						content.add(gender);
						content.add(nationality);
						content.add(illness);
						content.add(stage);
						hasEnoughData = true;
					} else {
						hasEnoughData = false;
					}
				}
				if (hasEnoughData) {
					File dirForReceivingFiles = new File(getFilesDir(),
							"questionaires");
					if (!dirForReceivingFiles.exists()) {
						dirForReceivingFiles.mkdirs();
					}
					new MainRetrieveQuestionaireTask(host, port,
							dirForReceivingFiles).execute(content);
					//TODO Toast
					System.out.println("Please wait for the questionaire to be retrieved");
				}
				else
				{
					String title = "Cannot Load Questionaire";
					String content = "Not all questions have been answered";
					SimpleDialogFragment newDialogFragment = SimpleDialogFragment.newInstance(title, content);
					newDialogFragment.show(getSupportFragmentManager(), INPUT_METHOD_SERVICE);
					v.setEnabled(true);
				}
			}
		});
		//spinner_Type = (Spinner) findViewById(R.id.spinner_Type);

		//spinner_stage = (Spinner) findViewById(R.id.spinner_Stage);
		spinner_stage.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				stage = (String) arg0.getItemAtPosition(arg2);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			}

		});
	}

	public ArrayList<String> getCountries() {
		ArrayList<String> countries = new ArrayList<String>();
		String[] locales = Locale.getISOCountries();

		for (String countryCode : locales) {

			Locale obj = new Locale("", countryCode);
			countries.add(obj.getDisplayCountry());

		}
		countries.add("Other");
		java.util.Collections.sort(countries);
		return countries;

	}

	public void notifyFinishPersonalDetail() {
		if(et_Fname.getText().toString().length() > 0 && et_Lname.getText().toString().length() > 0 && et_dateOfBirth.getText().toString().length() > 0){
			CNBtn.performClick();
			spinner_stage.setEnabled(true);
			spinner_Type.setEnabled(true);
		}
	}
	
	private DatePickerDialog.OnDateSetListener DateListener = new DatePickerDialog.OnDateSetListener() {

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			monthOfYear++;
			et_dateOfBirth.setText(dayOfMonth + "-" + monthOfYear + "-" + year);
		}
	};

	public String getContent(File questionaireFile) {
		String jsonString = "";
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(
					questionaireFile));
			String jsonLine = null;
			while ((jsonLine = bufferedReader.readLine()) != null) {
				jsonString = jsonString + jsonLine;
			}
			bufferedReader.close();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			String title = "Cannot Find Network";
			String content = "There is a socket error, please try again later";
			SimpleDialogFragment newDialogFragment = SimpleDialogFragment.newInstance(title, content);
			newDialogFragment.show(getSupportFragmentManager(), INPUT_SERVICE);	
			return null;
		}
		return jsonString.trim();
	}

	private void startQuestionActivity() {
		String jsonString = getContent(questionaireFile);
		if (jsonString.trim().length()>0) {
			startQuestionIntent.putExtra("JSON", jsonString);
			startQuestionIntent.putExtra("host", host);
			startQuestionIntent.putExtra("port", port);
			startQuestionIntent.putExtra("name", name);
			startQuestionIntent.putExtra("dateOfBirth", dateOfBirth);
			int extensionIndex = questionaireFile.getName().indexOf(".");
			String questionaireName = questionaireFile.getName().substring(0,
					extensionIndex);
			startQuestionIntent.putExtra("questionaire_name", questionaireName);
			startQuestionIntent.putExtra("list size", list_size);
			// delete questionaire file after finished
			questionaireFile.delete();
			startActivity(startQuestionIntent);
			MainActivity.this.finish();
		}
		else
		{
			String title = "Cannot find Questionare";
			String content = "Please choose the correct illness and stages";
			SimpleDialogFragment newDialogFragment = SimpleDialogFragment.newInstance(title, content);
			newDialogFragment.show(getSupportFragmentManager(), INPUT_METHOD_SERVICE);
			System.out.println("The questionaire file is empty, please try again later");
			b_startQuestionaire.setEnabled(true);
		}
	}

	/**
	 * This method starts network discovery
	 */
	private void startNetworkDiscovery() {
		try
		{
			InetAddress UDPAddress = InetAddress.getByName("255.255.255.255");
			int UDPPort = 5000;
			String serviceIDString = "#QUESTIONAIRE-SERVICE";
			
			MainNetworkDiscoveryTask networkDiscoveryTask = new MainNetworkDiscoveryTask(
					MainActivity.this, UDPAddress, UDPPort, serviceIDString);
			networkDiscoveryTask.execute();
		}
		catch (SocketException e) 
		{
			String title = "Cannot Find Network";
			String content = "There is a socket error, please try again later";
			SimpleDialogFragment newDialogFragment = SimpleDialogFragment.newInstance(title, content);
			newDialogFragment.show(getSupportFragmentManager(), INPUT_SERVICE);
			e.printStackTrace();
		} 
		catch (UnknownHostException e) {
			String title = "Cannot Find Network";
			String content = "Unknown Host Error";
			SimpleDialogFragment newDialogFragment = SimpleDialogFragment.newInstance(title, content);
			newDialogFragment.show(getSupportFragmentManager(), INPUT_METHOD_SERVICE);
			e.printStackTrace();
		}
	}

	protected class MainRetrieveQuestionaireTask extends
			RetrieveQuestionaireTask {

		public MainRetrieveQuestionaireTask(String host, int port,
				File dirForReceivingFiles) {
			super(host, port, dirForReceivingFiles);
		}

		@Override
		protected void onPostExecute(File result) {
			super.onPostExecute(result);
			if (result != null) {
				if (result.exists()) {
					questionaireFile = result;
					System.out.println("Questionaire Retrieved");
					startQuestionActivity();
				} else {
					System.out.println("Cannot retrieve questionaire");
				}
			}
		}
	}

	protected class MainRetrieveIllnessInfoTask extends RetrieveIllnessInfoTask {

		public MainRetrieveIllnessInfoTask(String host, int port) {
			super(host, port);
		}

		@Override
		protected void onPostExecute(HashMap<String, String[]> result) {
			super.onPostExecute(result);
			newPatientIllnessHashMap = result;
			if(CNBtn.isChecked())
			{
				populateIllnessAndStageSpinner(newPatientIllnessHashMap);
			}
		}
	}

	protected class MainRetrievePatientIllnessTask extends
			RetrievePatientIllness {

		public MainRetrievePatientIllnessTask(String host, int port) {
			super(host, port);
		}

		@Override
		protected void onPostExecute(HashMap<String, String[]> result) {
			super.onPostExecute(result);
			if(result!=null && result.size()>0)
			{
				patientIllnessHashMap = result;
				populateIllnessAndStageSpinner(patientIllnessHashMap);
				spinner_stage.setEnabled(true);
				spinner_Type.setEnabled(true);
			}
			else
			{
				String title = "Cannot Find User Details";
				String content = "Maybe you have not got your information recorded before, or this is your first time to the clinic";
				SimpleDialogFragment newDialogFragment = SimpleDialogFragment.newInstance(title, content);
				newDialogFragment.show(getSupportFragmentManager(), INPUT_METHOD_SERVICE);
				if(CYBtn.isChecked())
				{
					CNBtn.performClick();
				}
			}
		}
	}

	protected void populateIllnessAndStageSpinner(
			HashMap<String, String[]> result) {
		if (result != null) {
			//Get the illness HashMap from the socket(called result)
			illnessHashMap = result;
			illnessList = new ArrayList<String>();
			Iterator<String> illnessIterator = result.keySet().iterator();
			//Add the illness which is the key to spinner_Type
			while (illnessIterator.hasNext()) {
				illnessList.add(illnessIterator.next());
			}
			ArrayAdapter<String> illnessAdapter = new ArrayAdapter<String>(
					MainActivity.this, android.R.layout.simple_spinner_item,
					illnessList);
			illnessAdapter
					.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			spinner_Type.setAdapter(illnessAdapter);
			System.out.println("Populated illness Spinner");
			spinner_Type
					.setOnItemSelectedListener(new OnItemSelectedListener() {

						@Override
						public void onItemSelected(AdapterView<?> arg0,
								View arg1, int arg2, long arg3) {
							//Get the illness which is chosen from the list
							String selectedIllness = (String) arg0
									.getItemAtPosition(arg2);
							//store the illness in the activity
							illness = selectedIllness;
							//Get the Stage array which is the value in the hashmap and put them in spinner_type
							String[] stageArray = illnessHashMap
									.get(selectedIllness);
							ArrayAdapter<String> stageAdapter = new ArrayAdapter<String>(
									MainActivity.this,
									android.R.layout.simple_spinner_dropdown_item,
									stageArray);
							stageAdapter
									.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
							spinner_stage.setAdapter(stageAdapter);
						}

						@Override
						public void onNothingSelected(AdapterView<?> arg0) {
						}
					});
		} else {
			System.out.println("Cannot Retrieve Illness list");
		}
	}

	protected class MainNetworkDiscoveryTask extends
			DatagramNetworkDiscoveryTask {

		public MainNetworkDiscoveryTask(Context context,
				InetAddress UDPAddress, int UDPPort, String serviceIDString) throws SocketException {
			super(context, UDPAddress, UDPPort, serviceIDString);
		}

		@Override
		protected void onPostExecute(String[] result) {
			super.onPostExecute(result);
			if (result != null) {
				host = result[0];
				port = Integer.valueOf(result[1]);
				System.out.println("Server host is: " + host);
				System.out.println("Server" + Integer.toString(port));
				new MainRetrieveIllnessInfoTask(host, port).execute();
			} else {
				if (host != null) {
					new MainRetrieveIllnessInfoTask(host, port).execute();
				}
				System.out.println("Server IP Address not found");
			}
		}
	}

	protected static class DatePickerFragment extends DialogFragment implements
			DatePickerDialog.OnDateSetListener {
		DatePickerDialog dateDialog = null;

		public DatePickerFragment() {
			super();
		}

		public Dialog onCreateDialog(Bundle savedInstanceState) {

			Calendar calendar = Calendar.getInstance();
			int defaultDay = calendar.get(Calendar.DAY_OF_MONTH);
			int defaultMonth = calendar.get(Calendar.MONTH);
			int defaultYear = calendar.get(Calendar.YEAR);
			if (dateDialog == null) {
				dateDialog = new DatePickerDialog(getActivity(), this,
						defaultDay, defaultMonth, defaultYear);
			}
			return dateDialog;
		}

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			MainActivity mainActivity = (MainActivity) getActivity();

			String selectedDay = null;
			String selectedMonth = null;
			String selectedYear = String.valueOf(year);

			if (dayOfMonth > 9) {
				selectedDay = String.valueOf(dayOfMonth);
			} else {
				selectedDay = "0" + String.valueOf(dayOfMonth);
			}

			if (monthOfYear >= 9) {
				selectedMonth = String.valueOf(monthOfYear + 1);
			} else {
				selectedMonth = "0" + String.valueOf(monthOfYear + 1);
			}

			String dateOfBirth = selectedDay + "/" + selectedMonth + "/"
					+ selectedYear;
			mainActivity.et_dateOfBirth.setText(dateOfBirth);
		}
	}
}
