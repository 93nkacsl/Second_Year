package com.example.seg3androidclientgrouph;

import java.util.ArrayList;
import java.util.HashMap;

import android.R.layout;
import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class SingleChoice extends Fragment {

	private View FragmentView;
	private TextView tv;
	private Bundle bundle;
	private ArrayList<String> answers;
	private ArrayList<RadioButton> buttons_list;
	private LinearLayout layoutTwo;
	private LinearLayout linearLayout;
	private int qNum;
	private HashMap<Integer, Object> hashMap;
	private LayoutParams paramTV;
	private RadioGroup group;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstance) {

		InitializeLayout layout = new InitializeLayout();
		layout.start();
		try {
			layout.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// getActivity().setProgressBarIndeterminateVisibility(false);

		return FragmentView;
	}

	private class InitializeLayout extends Thread {
		public void run() {
			initialize();
			bundle = getArguments();
			String[] array = bundle.getStringArray("Answers");
			qNum = bundle.getInt("qNumber");
			System.out.println("Question Number: " + qNum);
			String question = bundle.getString("Question");
			tv.setText(question);
			hashMap = (HashMap<Integer, Object>) bundle.get("HashMap");
			for (int i = 0; i < array.length; i++) {
				answers.add(array[i]);
				final RadioButton button = new RadioButton(getActivity());
				button.setText(answers.get(i).toString());
				buttons_list.add(button);
				button.setTextSize(30);
				button.setId(i);

				try {
					if (hashMap.get(qNum).equals(button.getText().toString())) {
						button.setChecked(true);
					}

				} catch (NullPointerException e) {
					e.printStackTrace();
				}

				button.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// button.setChecked(true);
						System.out.println("Button: " + button.getId());
						for (int y = 0; y < buttons_list.size(); y++) {
							button.setChecked(true);
							if (button.getId() == buttons_list.get(y).getId()) {
								System.out.println("Buttons Array ID:"
										+ buttons_list.get(y).getId());

								// button.setChecked(true);

								hashMap.put(qNum, button.getText());
								System.out.println(hashMap.toString());
							} else {

								buttons_list.get(y).setChecked(false);
							}
						}

					}
				});

				group.addView(button);

			}

			layoutTwo.setGravity(Gravity.CENTER);
			layoutTwo.addView(group);
			linearLayout.addView(tv, paramTV);
			linearLayout.addView(layoutTwo);
			int color = bundle.getInt("backColor");
			linearLayout.setBackgroundColor(color);
			FragmentView = linearLayout;

		}

		/**
		 * This method creates the layouts and make the layout except for the
		 * radiobuttons.
		 */
		public void initialize() {
			answers = new ArrayList<String>();
			buttons_list = new ArrayList<RadioButton>();
			// The main Layout
			linearLayout = new LinearLayout(getActivity());
			linearLayout.setWeightSum(8);
			linearLayout.setOrientation(LinearLayout.VERTICAL);
			tv = new TextView(getActivity());
			tv.setGravity(Gravity.CENTER);
			tv.setTextSize(30);

			paramTV = new LayoutParams(
					android.view.ViewGroup.LayoutParams.MATCH_PARENT,
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
			paramTV.weight = 1;
			layoutTwo = new LinearLayout(getActivity());
			group = new RadioGroup(getActivity());
			group.setOrientation(RadioGroup.VERTICAL);
			group.setGravity(Gravity.CENTER);
		}
	}
}
