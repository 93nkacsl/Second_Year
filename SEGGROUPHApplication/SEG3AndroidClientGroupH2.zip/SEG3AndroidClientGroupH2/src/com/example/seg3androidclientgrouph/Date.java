package com.example.seg3androidclientgrouph;

import java.util.HashMap;

import DatePicker.SelectDateFragment;
import android.app.Fragment;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class Date extends Fragment {
	// implements OnDateSetListener
	private View view;
	private String question;
	private HashMap<Integer, Object> hashMap;
	private Bundle bundle;
	private int qNumber;
	private LinearLayout layout;
	private Button showDatePickerBtn;
	private SelectDateFragment newFragment;

	private EditText et_Input;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstance) {
		try {
			LayoutCreator ll = new LayoutCreator();
			ll.start();
			try {
				ll.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (Exception e) {

		}
		int color = bundle.getInt("backColor");
		layout.setBackgroundColor(color);
		view = layout;
		return view;

	}

	public class LayoutCreator extends Thread {
		public void run() {
			initialize();
			createLayout();

		}

		private void createLayout() {
			// LinearLayout questionLayout = new LinearLayout(getActivity());
			// questionLayout.setGravity(Gravity.CENTER);
			LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT,
					LayoutParams.WRAP_CONTENT);
			params.weight = 1;
			TextView tv_Question = new TextView(getActivity());
			tv_Question.setTextSize(30);
			tv_Question.setText(question);
			tv_Question.setGravity(Gravity.CENTER);
			LayoutParams paramTV = new LayoutParams(
					android.view.ViewGroup.LayoutParams.MATCH_PARENT,
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
			paramTV.weight = 1;

			LinearLayout layoutTwo = new LinearLayout(getActivity());
			et_Input = new EditText(getActivity());
			et_Input.setHint("Please Enter an Answer");
			layoutTwo.setGravity(Gravity.CENTER);
			et_Input.setGravity(Gravity.CENTER);
			layoutTwo.addView(et_Input);
			try {
				String text = (String) hashMap.get(qNumber);
				et_Input.setText(text);
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			showDatePickerBtn = new Button(getActivity());
			showDatePickerBtn.setText("Show Date");
			showDatePickerBtn.setGravity(Gravity.CENTER);
			layout.addView(tv_Question, paramTV);
			layout.addView(layoutTwo);
			et_Input.setKeyListener(null);
			et_Input.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					newFragment = new SelectDateFragment(et_Input, hashMap,
							qNumber);
					newFragment.show(getFragmentManager(), "DatePicker");
				}

			});
			// layout.addView(showDatePickerBtn);

			// showDatePickerBtn.setOnClickListener(new OnClickListener() {
			//
			// public void onClick(View view) {
			// newFragment = new SelectDateFragment(et_Input, hashMap,
			// qNumber);
			// newFragment.show(getFragmentManager(), "DatePicker");
			//
			// }
			// });

		}

		public void initialize() {
			bundle = getArguments();
			qNumber = bundle.getInt("qNumber");
			System.out.println("Question Number:" + qNumber);
			question = bundle.getString("Question");
			System.out.println("Question: " + question);
			hashMap = (HashMap<Integer, Object>) bundle.get("HashMap");
			System.out.println(hashMap.toString());
			layout = new LinearLayout(getActivity());
			layout.setOrientation(LinearLayout.VERTICAL);
			layout.setWeightSum(8);

		}

	}

}