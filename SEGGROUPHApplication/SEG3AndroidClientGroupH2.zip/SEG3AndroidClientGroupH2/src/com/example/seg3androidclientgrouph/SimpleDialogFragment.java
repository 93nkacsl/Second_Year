package com.example.seg3androidclientgrouph;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

public class SimpleDialogFragment extends DialogFragment
{        
        String title;
        String content;
        /**
         * This method creates a new dialogue fragment from the title and content with a simple dialog box
         * @param String title int in value resources, containing title String  
         * @param String content the int of the layout xml file
         * @return a dialog fragment with title content and an ok button;
         */
        public static SimpleDialogFragment newInstance(String title, String content)
        {
                SimpleDialogFragment newDialogFragment = new SimpleDialogFragment();
                
                Bundle args = new Bundle();
                args.putString("title", title);
                args.putString("content", content);
                newDialogFragment.setArguments(args);
                return newDialogFragment;
        }
        
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
                title = getArguments().getString("title");
                content = getArguments().getString("content");
                return createDialog(title, content);
        }
        
        /**
         * This method creates a new dialogue from the title and content (from resources) of the dialogue
         * @param String title int in value resources, containing title String  
         * @param String content the int of the layout xml file
         */
        public Dialog createDialog(String title, String content)
        {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
                dialogBuilder.setTitle(title);
                dialogBuilder.setMessage(content);
                dialogBuilder.setNeutralButton("OK", new OKButtonListener());
                return dialogBuilder.create();
        }
        
        protected class OKButtonListener implements OnClickListener
        {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                }
        }
}