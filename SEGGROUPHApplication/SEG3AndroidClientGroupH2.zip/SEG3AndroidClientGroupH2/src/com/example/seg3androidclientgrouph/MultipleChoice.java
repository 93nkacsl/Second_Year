package com.example.seg3androidclientgrouph;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Fragment;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MultipleChoice extends Fragment {
	private View view;
	private Bundle bundle;
	private ArrayList<String> answers;
	private LinearLayout layout;
	private LinearLayout.LayoutParams paramTV;
	private String question;
	private ArrayList<CheckBox> checkBoxes;
	private ArrayList<String> validAnswers;
	private int qNumber;
	private HashMap<Integer, Object> hashMap;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstance) {
		// initialize();
		// container.setBackgroundColor(Color.RED);
		MyLayout myLayout = new MyLayout();
		myLayout.run();
		try {
			myLayout.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int color = bundle.getInt("backColor");
		layout.setBackgroundColor(color);
		view = layout;
		return view;
	}

	public class MyLayout extends Thread {
		public void run() {
			initialize();
			createRadioLayout();
			// System.out.println("IT RAN");
		}

		public void initialize() {
			layout = new LinearLayout(getActivity());
			layout.setWeightSum(8);
			layout.setOrientation(LinearLayout.VERTICAL);
			// layout.setGravity(Gravity.CENTER);
			answers = new ArrayList<String>();
			bundle = getArguments();
			checkBoxes = new ArrayList<CheckBox>();
			question = (String) bundle.get("Question");
			validAnswers = new ArrayList<String>();
			qNumber = bundle.getInt("qNumber");
			hashMap = (HashMap<Integer, Object>) bundle.get("HashMap");
			System.out.println("Question Number: " + qNumber);
		}

		public void createRadioLayout() {
			LinearLayout radioButtons = new LinearLayout(getActivity());
			radioButtons.setGravity(Gravity.CENTER);
			radioButtons.setOrientation(LinearLayout.HORIZONTAL);
			String[] array = bundle.getStringArray("Answers");
			for (int i = 0; i < array.length; i++) {
				answers.add(array[i]);
				System.out.println("Answer: " + array[i]);
			}
			for (int i = 0; i < answers.size(); i++) {
				CheckBox box = new CheckBox(getActivity());
				box.setText(answers.get(i).toString());
				box.setTextSize(30);
				checkBoxes.add(box);
				radioButtons.addView(box);
			}
			try {
				ArrayList<String> list = (ArrayList<String>) hashMap
						.get(qNumber);
				for (int i = 0; i < checkBoxes.size(); i++) {
					for (int y = 0; y < list.size(); y++) {
						if (checkBoxes.get(i).getText().toString()
								.equals(list.get(y).toString())) {
							checkBoxes.get(i).setChecked(true);
						}
					}
				}

			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			for (int i = 0; i < answers.size(); i++) {
				final int x = i;
				checkBoxes.get(i).setOnCheckedChangeListener(
						new OnCheckedChangeListener() {

							public void onCheckedChanged(
									CompoundButton buttonView, boolean isChecked) {
								if (!isChecked) {
									validAnswers.remove(checkBoxes.get(x)
											.getText());

								} else {
									validAnswers.add(checkBoxes.get(x)
											.getText().toString());

								}
								hashMap.put(qNumber, validAnswers);
								// System.out.println(validAnswers.toString());
								System.out.println("HASHMAP: "
										+ hashMap.toString());
							}
						});
			}
			paramTV = new LinearLayout.LayoutParams(
					android.view.ViewGroup.LayoutParams.MATCH_PARENT,
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
			paramTV.weight = 1;
			TextView tv = new TextView(getActivity());
			tv.setTextSize(30);
			tv.setGravity(Gravity.CENTER);
			tv.setText(question);
			layout.addView(tv, paramTV);
			layout.addView(radioButtons);
		}
	}

}
