package com.example.seg3androidclientgrouph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.socket.SendHashMapAnswerTask;

public class Questionaire extends Activity {
	private ListView lv_Questions;
	private String QuestionsInJSON;
	// private Button button;
	private JSONArray array;
	// private static final int id_Fragment = 101010;
	private FragmentTransaction fragmentTransaction;
	private SingleChoice singleChoice;
	private MultipleChoice multiple;
	private OpenEnded openEnded;
	/**
	 * Text colors
	 */
	private int textColor = Color.parseColor("#CC182A");
	private int backgroundColor = Color.parseColor("#8BBEE7");
	private int bloodRed = Color.parseColor("#800000");
	private int cottonWhite = Color.parseColor("#FFFFFF");
	/**
	 * Text Size
	 */
	private int fontSize, titleSize;

	private int questionNumber = 1;
	private TextView tv_QuestionNumber;
	private Button b_Submit;
	private static HashMap<Integer, Object> hashmap = new HashMap<Integer, Object>();
	private int currentFragment = 0;
	private int x;
	private Date date;
	private Numerical numerical;
	private LinearLayout ll_Submit;
	private LinearLayout ll;
	/**
	 * VOICE RECOGNITION
	 */
	private ProgressBar progressBar;
	// These Variable are used for the TextToSpeech recognition
	private String question = null;
	private String q_Type = null;
	private TextToSpeech speech;
	private String[] myAnswer;
	private static final int REQUEST_CODE = 1234;
	private boolean HEARING_ACTIVATION = true;
	private String questionaireName;
	private String host;
	private int port;

	// Help Colors Part

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		fontSize = 30;
		titleSize = 50;

		setContentView(R.layout.activity_questionaire);

		ll_Submit = (LinearLayout) findViewById(R.id.ll_Submit);
		b_Submit = (Button) findViewById(R.id.b_Submit);
		tv_QuestionNumber = (TextView) findViewById(R.id.tv_QuestionNumber);
		lv_Questions = (ListView) findViewById(R.id.listview_Questions);
		ll = (LinearLayout) findViewById(R.id.ll);
		ll.setBackgroundColor(cottonWhite);
		setColourPrefrences(bloodRed, cottonWhite, fontSize, titleSize);
		progressBar = (ProgressBar) findViewById(R.id.progrssBar);
		new Operations().execute();
	}

	/**
	 * This method sets the background and text color
	 * 
	 * @param textColor
	 * @param backgroundColor
	 */
	public void setColourPrefrences(int textColor, int backgroundColor,
			int fontColor, int titleColor) {
		tv_QuestionNumber.setTextSize(titleColor);
		lv_Questions.setBackgroundColor(textColor);
		tv_QuestionNumber.setTextColor(textColor);
		ll_Submit.setBackgroundColor(backgroundColor);
	}

	public class Operations extends AsyncTask<String, Void, String> {
		ProgressDialog dialog;

		@Override
		protected void onPostExecute(String result) {
			progressBar.setVisibility(View.GONE);
			lv_Questions.setVisibility(View.VISIBLE);
			ll.setVisibility(View.VISIBLE);
			dialog.dismiss();
			super.onPostExecute(result);

		}

		@Override
		protected void onPreExecute() {
			progressBar.setVisibility(View.VISIBLE);
			lv_Questions.setVisibility(View.GONE);
			ll.setVisibility(View.GONE);
			dialog = ProgressDialog.show(Questionaire.this,
					"Loading Questionaire", "Please Wait!", true);
			super.onPreExecute();

		}

		@Override
		protected String doInBackground(String... params) {

			// This is to do with the help color part

			// FrameLayout layout = (FrameLayout)
			// findViewById(R.id.linearLayout);
			ArrayAdapter adapter = new ArrayAdapter<String>(Questionaire.this,
					R.layout.custom_layout,
					updateListview());
			lv_Questions.setAdapter(adapter);
			// Sets the layout as the first fragment
			setFragment(questionNumber);
			lv_Questions.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long id) {
					// requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
					// setProgressBarIndeterminateVisibility(true);

					x = position + 1;
					setFragment(x);
					questionNumber = x;

					tv_QuestionNumber.setText("Question " + x);
					// setProgressBarIndeterminateVisibility(false);
					if (x == getNUmberofQuestions()) {
						ll_Submit.setVisibility(View.VISIBLE);
						/**
						 * 
						 */
						b_Submit.setOnClickListener(new OnClickListener() {

							@Override
							public void onClick(View v) {
								String patientName = getIntent().getStringExtra("name");
								String dateOfBirth = getIntent().getStringExtra("dateOfBirth");
								Intent intent = getIntent();
								String host = intent.getStringExtra("host");
								int port = intent.getIntExtra("port", 0);
								String questionaireName = intent
										.getStringExtra("questionaire_name");
								String[] params = { hashmap.toString(),
										questionaireName};
								new QuestionaireSendAnswerTask(host, port)
										.execute(params);
								System.out.println("RESULT HASHMAP: "
										+ hashmap.toString());
								if (getNUmberofQuestions() == hashmap.size()) {
								} else {
									Toast.makeText(Questionaire.this,
											"Please answer all the questions",
											Toast.LENGTH_SHORT).show();
								}
								returnToNewMainActivity();
							}
						});
					} else {
						ll_Submit.setVisibility(View.INVISIBLE);
					}
				}

			});

			speech = new TextToSpeech(Questionaire.this,
					new TextToSpeech.OnInitListener() {

						@Override
						public void onInit(int status) {
							if (status != TextToSpeech.ERROR) {
								speech.setLanguage(Locale.US);
								System.out.println("WORKS");
								System.out.println(question);
							}
						}
					});
			return null;
		}
	}

	/**
	 * Removes a fragment from the page
	 * 
	 * @param currentFragment
	 */
	private void RemoveCurrentFragment(int currentFragment) {
		if (currentFragment == 0) {

		}
		if (currentFragment == 1) {
			getFragmentManager().beginTransaction().remove(singleChoice)
					.commit();

		}
		if (currentFragment == 2) {
			getFragmentManager().beginTransaction().remove(multiple).commit();
		}
		if (currentFragment == 3) {
			getFragmentManager().beginTransaction().remove(openEnded).commit();
		}
		if (currentFragment == 4) {
			getFragmentManager().beginTransaction().remove(numerical).commit();
		}
		if (currentFragment == 5) {
			getFragmentManager().beginTransaction().remove(date).commit();
		}

	}

	public String[] getAnswers(int qNumber) {
		String[] arr = null;
		try {
			JSONObject object = array.getJSONObject(qNumber - 1);
			JSONArray a = object.getJSONArray("Answers");
			arr = new String[a.length()];
			for (int i = 0; i < a.length(); i++) {
				arr[i] = a.getString(i);
				System.out.println(a.get(i).toString());
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return arr;

	}

	/**
	 * Inserts a fragment into the layout
	 */
	public void setFragment(int y) {
		// System.out.println(y);

		System.out.println(getQuestionType(y));
		if (getQuestionType(y).equals("Single Choice")) {

			RemoveCurrentFragment(currentFragment);

			System.out.println("Gereft");
			currentFragment = 1;
			singleChoice = new SingleChoice();
			Bundle bundle = new Bundle();
			bundle.putSerializable("HashMap", hashmap);
			bundle.putString("Question", getQuestion(y));
			question = getQuestion(y);
			q_Type = getQuestionType(y);
			myAnswer = getAnswers(y);
			bundle.putInt("backColor",cottonWhite);
			bundle.putStringArray("Answers", getAnswers(y));
			bundle.putInt("qNumber", y);
			singleChoice.setArguments(bundle);

			fragmentTransaction = getFragmentManager().beginTransaction();
			fragmentTransaction.add(R.id.linearLayout, singleChoice);
			fragmentTransaction.commit();
			// singleChoice.setText(getQuestion(y));

		}
		if (getQuestionType(y).equals("Multiple Choice")) {
			// RemoveCurrentFragment(currentFragment);
			RemoveCurrentFragment(currentFragment);
			currentFragment = 2;
			multiple = new MultipleChoice();
			Bundle bundle = new Bundle();
			bundle.putSerializable("HashMap", hashmap);

			question = getQuestion(y);
			q_Type = getQuestionType(y);
			myAnswer = getAnswers(y);
			bundle.putString("Question", getQuestion(y));
			bundle.putStringArray("Answers", getAnswers(y));
			bundle.putInt("qNumber", y);
			bundle.putInt("backColor", cottonWhite);
			multiple.setArguments(bundle);

			fragmentTransaction = getFragmentManager().beginTransaction();
			fragmentTransaction.add(R.id.linearLayout, multiple);
			fragmentTransaction.commit();

		}
		if (getQuestionType(y).equals("Open Ended")) {
			RemoveCurrentFragment(currentFragment);
			currentFragment = 3;
			// System.out.println("Gereft!");
			openEnded = new OpenEnded();
			Bundle bundle = new Bundle();
			question = getQuestion(y);
			q_Type = getQuestionType(y);
			bundle.putSerializable("HashMap", hashmap);
			bundle.putString("Question", getQuestion(y));
			bundle.putInt("backColor", cottonWhite);
			bundle.putInt("qNumber", y);
			openEnded.setArguments(bundle);
			fragmentTransaction = getFragmentManager().beginTransaction();
			fragmentTransaction.add(R.id.linearLayout, openEnded);
			fragmentTransaction.commit();

		}
		if (getQuestionType(y).equals("Numerical")) {
			RemoveCurrentFragment(currentFragment);
			currentFragment = 4;

			numerical = new Numerical();
			Bundle bundle = new Bundle();
			bundle.putSerializable("HashMap", hashmap);
			bundle.putInt("backColor", cottonWhite);
			bundle.putString("Question", getQuestion(y));
			bundle.putInt("qNumber", y);
			question = getQuestion(y);
			q_Type = getQuestionType(y);
			numerical.setArguments(bundle);
			fragmentTransaction = getFragmentManager().beginTransaction();
			fragmentTransaction.add(R.id.linearLayout, numerical);
			fragmentTransaction.commit();

		}
		if (getQuestionType(y).equals("Date")) {
			RemoveCurrentFragment(currentFragment);
			currentFragment = 5;
			date = new Date();
			Bundle bundle = new Bundle();
			bundle.putSerializable("HashMap", hashmap);
			bundle.putInt("backColor", cottonWhite);
			bundle.putString("Question", getQuestion(y));
			bundle.putInt("qNumber", y);
			question = getQuestion(y);
			q_Type = getQuestionType(y);
			date.setArguments(bundle);

			fragmentTransaction = getFragmentManager().beginTransaction();
			fragmentTransaction.add(R.id.linearLayout, date);
			fragmentTransaction.commit();

		}

		// System.out.println(QuestionsInJSON);

	}

	/**
	 * This method return the Questions within the json file
	 * 
	 * @param questionNumber
	 * @return
	 */
	public String getQuestion(int questionNumber) {
		String question = "";
		try {
			JSONObject object = (JSONObject) array.get(questionNumber - 1);
			question = object.getString("Question");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return question;

	}

	public String getQuestionType(int questionNumber) {
		String content = "";
		try {
			JSONObject object = array.getJSONObject(questionNumber - 1);
			content = object.getString("Question_Type");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return content;

	}

	public String[] updateListview() {
		int x = getNUmberofQuestions();
		String[] lv_Array = new String[x];
		for (int i = 0; i < x; i++) {
			int y = i + 1;
			lv_Array[i] = "Question " + y;

		}
		return lv_Array;
	}

	/**
	 * Return the number of questions to be used for the listView
	 * 
	 * @return the number of questions
	 */
	public int getNUmberofQuestions() {
		QuestionsInJSON = (String) getIntent().getExtras().get("JSON");
		int y = 0;
		try {
			if(QuestionsInJSON!=null && QuestionsInJSON.length()>0)
			{
				array = new JSONArray(QuestionsInJSON);
				y = array.length();
			}
			else
			{
				System.out.println("There is no JSON that can be parsed into a questionaire");
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return y;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		getMenuInflater().inflate(R.menu.questionaire, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {

		case R.id.b_Reset:
			hashmap.clear();
			setFragment(x);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/**
	 * THE VOICE RECOGNITION
	 */

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		if (HEARING_ACTIVATION) {
			if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
				System.out.println("Volume Up Pressed");
				// speech.speak(q_Type, TextToSpeech.QUEUE_FLUSH, null);
				if (q_Type.equals("Single Choice")) {
					speech.speak("The Answers Are", TextToSpeech.QUEUE_ADD,
							null);
					for (int i = 0; i < myAnswer.length; i++) {
						String tet = myAnswer[i];
						System.out.println(tet);
						speech.speak(tet, TextToSpeech.QUEUE_ADD, null);
					}
				}
				if (q_Type.equals("Multiple Choice")) {
					speech.speak("The Answers Are", TextToSpeech.QUEUE_ADD,
							null);
					for (int i = 0; i < myAnswer.length; i++) {
						String tet = myAnswer[i];
						System.out.println(i + "");
						speech.speak(tet, TextToSpeech.QUEUE_ADD, null);
					}
				}
				return true;
			}
			if (keyCode == KeyEvent.KEYCODE_MENU) {
				voiceRecognition();
			}
			if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
				speech.speak(question, TextToSpeech.QUEUE_FLUSH, null);
			}
		}

		return super.onKeyDown(keyCode, event);

	}

	// @Override
	// public boolean onKeyLongPress(int keyCode, KeyEvent event) {
	// if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
	// Log.w("VOL", "UP");
	// }
	// if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
	// Log.w("VOL", "DOWN");
	// }
	// return true;
	// }

	@Override
	public void onDestroy() {
		// Don't forget to shutdown!
		if (speech != null) {
			speech.stop();
			speech.shutdown();
		}
		super.onDestroy();
	}

	private void voiceRecognition() {
		Intent myIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
		myIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, "en-US");
		myIntent.putExtra(RecognizerIntent.EXTRA_PROMPT,
				"AndroidBite Voice Recognition...");
		startActivityForResult(myIntent, REQUEST_CODE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
			ArrayList<String> matches = data
					.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
			VOICERECOG voice = new VOICERECOG(matches);

			voice.start();
			try {
				voice.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * Motion Gestures Class
	 */

	/**
	 * This is the class that executes the voice recognition.
	 * 
	 * @author AmirNasiri
	 * 
	 */
	public class VOICERECOG extends Thread {
		ArrayList<String> matches;

		public VOICERECOG(ArrayList<String> matches) {
			this.matches = matches;
		}

		public void run() {
			setAnswer(matches);
		}

		private void setAnswer(ArrayList<String> matches) {
			boolean t = false;
			if (q_Type.equals("Single Choice")) {
				// System.out.println("WORKKKKKKKKKS");
				for (int i = 0; i < matches.size(); i++) {
					// System.out.println("MATCHES: " + matches.get(i));
					for (int y = 0; y < myAnswer.length; y++) {
						// System.out.println("ANSWERSL " + myAnswer[y]);
						if (matches.get(i).toLowerCase()
								.equals(myAnswer[y].toLowerCase())) {
							hashmap.put(questionNumber, myAnswer[y]);
							System.out
									.println("HASHMAP: " + hashmap.toString());
							setFragment(questionNumber);
							t = true;
							break;
						}
					}
					if (t == true) {
						break;
					}
				}
			}
			if (q_Type.equals("Multiple Choice")) {
				ArrayList<String> list_Of_Answers;
				try {
					list_Of_Answers = (ArrayList<String>) hashmap.get(x);
					for (int i = 0; i < matches.size(); i++) {

						// System.out.println("MATCHES: " + matches.get(i));
						for (int y = 0; y < myAnswer.length; y++) {
							// System.out.println("ANSWERSL " + myAnswer[y]);
							if (matches.get(i).toLowerCase()
									.equals(myAnswer[y].toLowerCase())) {
								list_Of_Answers.add(myAnswer[y]);

								t = true;
								break;
							}
						}
						if (t == true) {
							break;
						}
					}

				} catch (NullPointerException e) {
					list_Of_Answers = new ArrayList<String>();
					for (int i = 0; i < matches.size(); i++) {

						// System.out.println("MATCHES: " + matches.get(i));
						for (int y = 0; y < myAnswer.length; y++) {
							// System.out.println("ANSWERSL " + myAnswer[y]);
							if (matches.get(i).toLowerCase()
									.equals(myAnswer[y].toLowerCase())) {
								list_Of_Answers.add(myAnswer[y]);

								t = true;
								break;
							}
						}
						if (t == true) {
							break;
						}
					}

				}
				hashmap.put(questionNumber, list_Of_Answers);
				System.out.println("HASHMAP: " + hashmap);
				setFragment(questionNumber);
			}
			if (q_Type.equals("Open Ended")) {
				hashmap.put(questionNumber, matches.get(0).toString());
				setFragment(questionNumber);
			}
			if (q_Type.equals("Date")) {
				hashmap.put(questionNumber, matches.get(0).toString());
				setFragment(questionNumber);
			}
			if (q_Type.equals("Numerical")) {
				try {
					for (int i = 0; i < matches.size(); i++) {
						hashmap.put(questionNumber,
								Integer.parseInt(matches.get(i)));
						setFragment(questionNumber);
						break;
					}
				} catch (NumberFormatException e) {

				}
			}

		}
	}
	public void returnToNewMainActivity()
	{
		//TODO Don't know whether this is correct or not
		Questionaire.this.finish();
		Intent intent = new Intent(this, MainActivity.class);
		overridePendingTransition(0,0);
		intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
		startActivity(intent);
	}

	private class QuestionaireSendAnswerTask extends SendHashMapAnswerTask {

		public QuestionaireSendAnswerTask(String host, int port) {
			super(host, port);
			// TODO Auto-generated constructor stub
		}

		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);
			if (result = true) {
				System.out.println("Answer has been sent");
			}
		}
	}
	// Ont ounch
}
