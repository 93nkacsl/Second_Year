package DatePicker;

import java.util.Calendar;
import java.util.HashMap;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.EditText;

public class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

	private EditText mEdit;
	private int qNumber;
	private HashMap<Integer, Object> hashmap;

	public SelectDateFragment(EditText mEdit, HashMap<Integer, Object> hashmap,
			int qNumber) {
		this.mEdit = mEdit;
		this.hashmap = hashmap;
		this.qNumber = qNumber;

	}

	public Dialog onCreateDialog(Bundle savedInstanceState) {
		final Calendar calendar = Calendar.getInstance();
		int yy = calendar.get(Calendar.YEAR);
		int mm = calendar.get(Calendar.MONTH);
		int dd = calendar.get(Calendar.DAY_OF_MONTH);
		return new DatePickerDialog(getActivity(), this, yy, mm, dd);
	}

	public void onDateSet(DatePicker view, int yy, int mm, int dd) {
		mEdit.setText(mm + "/" + dd + "/" + yy);
		hashmap.put(qNumber, mm + "/" + dd + "/" + yy);
		System.out.println(hashmap.toString());
	}
}
